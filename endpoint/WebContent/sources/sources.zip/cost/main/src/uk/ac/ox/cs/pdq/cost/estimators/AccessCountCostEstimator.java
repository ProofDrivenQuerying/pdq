package uk.ac.ox.cs.pdq.cost.estimators;

import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_COUNT;
import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_TIME;

import java.util.Collection;

import uk.ac.ox.cs.pdq.logging.performance.StatisticsCollector;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.DoubleCost;
import uk.ac.ox.cs.pdq.plan.Plan;

import com.google.common.eventbus.EventBus;


/**
 * A simple cost estimator.
 * According to this implementation, the cost of a plan equals the number of the accesses.
 *
 * @author Efthymia Tsamoura
 */
public class AccessCountCostEstimator<P extends Plan> implements SimpleCostEstimator<P> {

	protected final StatisticsCollector stats;
	
	/**
	 * Default constructor. By-passed any statistic collection.
	 */
	public AccessCountCostEstimator() {
		this(null, false);
	}

	/**
	 * Default constructor
	 * @param eventBus
	 * @param collectStats
	 */
	public AccessCountCostEstimator(EventBus eventBus, boolean collectStats) {
		this(new StatisticsCollector(collectStats, eventBus));
	}

	/**
	 * Constructor
	 * @param stats
	 */
	public AccessCountCostEstimator(StatisticsCollector stats) {
		this.stats = stats;
	}

	/**
	 * @return SimpleCountCostEstimator<P,S>
	 * @see uk.ac.ox.cs.pdq.cost.estimators.SimpleCostEstimator#clone()
	 */
	@Override
	public AccessCountCostEstimator<P> clone() {
		return new AccessCountCostEstimator<>(this.stats.clone());
	}

	/**
	 * @param plan P
	 * @return DoubleCost
	 * @see uk.ac.ox.cs.pdq.cost.estimators.CostEstimator#cost(P)
	 */
	@Override
	public DoubleCost cost(P plan) {
		DoubleCost result = this.cost(plan.getAccesses());
		plan.setCost(result);
		return result;
	}

	/**
	 * @param plan P
	 * @return Cost
	 * @see uk.ac.ox.cs.pdq.cost.estimators.SimpleCostEstimator#estimateCost(P)
	 */
	@Override
	public DoubleCost estimateCost(P plan) {
		return this.cost(plan.getAccesses());
	}

	/**
	 * @param accesses Collection<AccessOperator>
	 * @return DoubleCost
	 * @see uk.ac.ox.cs.pdq.costs.SimpleCostEstimator#cost(Collection<AccessOperator>)
	 */
	@Override
	public DoubleCost cost(Collection<AccessOperator> accesses) {
		this.stats.start(COST_ESTIMATION_TIME);
		DoubleCost result = new DoubleCost(accesses.size());
		this.stats.stop(COST_ESTIMATION_TIME);
		this.stats.increase(COST_ESTIMATION_COUNT, 1);
		return result;
	}

}
