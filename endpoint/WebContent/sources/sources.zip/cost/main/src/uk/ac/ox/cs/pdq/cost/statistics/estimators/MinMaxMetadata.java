package uk.ac.ox.cs.pdq.cost.statistics.estimators;

import uk.ac.ox.cs.pdq.algebra.RelationalOperator;
import uk.ac.ox.cs.pdq.plan.EstimateProvider;

/**
 * @author Julien Leblay
 */
public class MinMaxMetadata implements EstimateProvider<RelationalOperator> {

	/**
	 * @return LogicalOperator
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#getParent()
	 */
	@Override
	public RelationalOperator getParent() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return Double
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#getInputCardinality()
	 */
	@Override
	public Double getInputCardinality() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return Double
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#getOutputCardinality()
	 */
	@Override
	public Double getOutputCardinality() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param l Double
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#setInputCardinality(Double)
	 */
	@Override
	public void setInputCardinality(Double l) {
		// TODO Auto-generated method stub

	}

	/**
	 * @param l Double
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#setOutputCardinality(Double)
	 */
	@Override
	public void setOutputCardinality(Double l) {
		// TODO Auto-generated method stub

	}

	/**
	 * @param parent LogicalOperator
	 * @see uk.ac.ox.cs.pdq.plan.EstimateProvider#setParent(RelationalOperator)
	 */
	@Override
	public void setParent(RelationalOperator parent) {
		// TODO Auto-generated method stub

	}
}
