package uk.ac.ox.cs.pdq.cost.estimators;

import uk.ac.ox.cs.pdq.plan.Cost;
import uk.ac.ox.cs.pdq.plan.Plan;


/**
 * Returns the cost of an input plan.
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 *
 */
public interface CostEstimator<P extends Plan> {
	/**
	 * Estimates and sets the cost of the input plan
	 * @param plan
	 * @return the cost of the input plan
	 */
	Cost cost(P plan);
	
	/**
	 * Estimates the cost of the input plan
	 * @param plan
	 * @return the cost of the input plan
	 */
	Cost estimateCost(P plan);
	
	CostEstimator<P> clone();
}
