package uk.ac.ox.cs.pdq.cost.statistics.estimators;

import uk.ac.ox.cs.pdq.algebra.Access;
import uk.ac.ox.cs.pdq.algebra.DependentAccess;
import uk.ac.ox.cs.pdq.algebra.Distinct;
import uk.ac.ox.cs.pdq.algebra.Join;
import uk.ac.ox.cs.pdq.algebra.RelationalOperator;
import uk.ac.ox.cs.pdq.algebra.Scan;
import uk.ac.ox.cs.pdq.algebra.Selection;
import uk.ac.ox.cs.pdq.algebra.Union;
import uk.ac.ox.cs.pdq.db.Schema;

/**
 * Compute the estimated input and output cardinalities of a logical operator
 * and its descendants, based on a min/max estimation.
 * I.e. for each relation attributes, the min, max and number of distinct values
 * are known, and cardinality are computed under the assumption that the data
 * distribution is uniform.
 *
 * @author Julien Leblay
 */
public class MinMaxCardinalityEstimator extends AbstractCardinalityEstimator<MinMaxMetadata> {

	protected final Schema schema;

	/**
	 * Constructor for MinMaxCardinalityEstimator.
	 * @param schema Schema
	 */
	public MinMaxCardinalityEstimator(Schema schema) {
		this.schema = schema;
	}

	/**
	 * @return MinMaxCardinalityEstimator
	 * @see uk.ac.ox.cs.pdq.cost.statistics.estimators.CardinalityEstimator#clone()
	 */
	@Override
	public MinMaxCardinalityEstimator clone() {
		return new MinMaxCardinalityEstimator(this.schema);
	}

	/**
	 * @param o Scan
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Scan o) {
		return (double) this.schema.getRelation(o.getRelation().getName()).getMetadata().getSize();
	}

	/**
	 * @param o LogicalOperator
	 * @return MinMaxMetadata
	 */
	@Override
	protected MinMaxMetadata initMetadata(RelationalOperator o) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param o Access
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Access o) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	/**
	 * @param o DependentAccess
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(DependentAccess o) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	/**
	 * Method estimateOutput.
	 * @param o Join
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Join o) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	/**
	 * @param o Selection
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Selection o) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	/**
	 * @param o Distinct
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Distinct o) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	/**
	 * @param o Union
	 * @return Double
	 */
	@Override
	protected Double estimateOutput(Union o) {
		// TODO Auto-generated method stub
		return 0.0;
	}
}
