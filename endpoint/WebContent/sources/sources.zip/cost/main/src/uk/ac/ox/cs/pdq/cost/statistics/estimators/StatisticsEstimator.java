package uk.ac.ox.cs.pdq.cost.statistics.estimators;

import uk.ac.ox.cs.pdq.plan.Plan;

/**
 * 
 * @author Efthymia Tsamoura
 *
 */
public interface StatisticsEstimator {
	
	void estimateStatistics(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @param operator
	 * @return
	 * 		the input cardinality of the input operator given the input plan
	 */
	double getInputCardinality(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @param operator
	 * @return
	 * 		the output cardinality of the input operator given the input plan
	 */
	double getOutputCardinality(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @param operator
	 * @return
	 * 		the estimated resultsize per invocation of the input access given the input plan
	 */
	double getERPSI(Plan plan);
	
	StatisticsEstimator clone();

}
