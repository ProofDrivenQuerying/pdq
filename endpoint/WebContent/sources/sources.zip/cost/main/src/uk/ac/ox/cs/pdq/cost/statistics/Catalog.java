
package uk.ac.ox.cs.pdq.cost.statistics;


import uk.ac.ox.cs.pdq.algebra.predicates.AttributeEqualityPredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.Predicate;
import uk.ac.ox.cs.pdq.db.Attribute;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.Plan;

/**
 * The database statistics 
 * @author Efthymia Tsamoura
 *
 */
public interface Catalog {

	/**
	 * 
	 * @param plan
	 * @return the selectivity of the input plan
	 */
	double getSelectivity(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @param predicate
	 * @return the selectivity of the predicate conditioned on the plan
	 */
	double getSelectivity(Plan plan, Predicate predicate);
	
	/**
	 * 
	 * @param relation
	 * @param attribute
	 * @return
	 * 		the selectivity associated to the input attribute
	 */
	double getSelectivity(Relation relation, Attribute attribute);
	
	/**
	 * 
	 * @param left
	 * @param right
	 * @param predicate
	 * @return the selectivityof the attribute equality predicate
	 */
	double getSelectivity(Relation left, Relation right, AttributeEqualityPredicate predicate);
	
	/**
	 * 
	 * @param relation
	 * @return the cardinality of the input relation
	 */
	double getCardinality(Relation relation);
	
	/**
	 * 
	 * @param relation
	 * @param attribute
	 * @return the cardinality of the input attribute
	 */
	double getCardinality(Relation relation, Attribute attribute);
	
	/**
	 * 
	 * @param plan
	 * @return the estimated result size per invocation of the input plan
	 */
	double getERPSI(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @return the estimated result size per invocation of the input access
	 */
	double getERPSI(AccessOperator access);

	/**
	 * 
	 * @param plan
	 * @return the response time of the input plan
	 */
	double getResponseTime(Plan plan);
	
	/**
	 * 
	 * @param plan
	 * @return the cost of the input plan
	 */
	double getCost(Plan plan);
	
	Catalog clone();
}
