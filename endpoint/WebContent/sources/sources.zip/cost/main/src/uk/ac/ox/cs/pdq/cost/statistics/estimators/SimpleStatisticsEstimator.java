/**
 * 
 */
package uk.ac.ox.cs.pdq.cost.statistics.estimators;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;

import uk.ac.ox.cs.pdq.algebra.DependentJoin;
import uk.ac.ox.cs.pdq.algebra.Join;
import uk.ac.ox.cs.pdq.algebra.NaryOperator;
import uk.ac.ox.cs.pdq.algebra.Projection;
import uk.ac.ox.cs.pdq.algebra.Selection;
import uk.ac.ox.cs.pdq.cost.statistics.SimpleCatalog;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.DAGPlan;
import uk.ac.ox.cs.pdq.plan.Plan;

import com.google.common.base.Preconditions;

/**
 * Estimates the response size per invocation of a plan
 * @author Efthymia Tsamoura
 *
 */
public class SimpleStatisticsEstimator implements StatisticsEstimator{

	private final SimpleCatalog catalog;
	private final Map<Plan,Double> inputCardinalities;
	private final Map<Plan,Double> outputCardinalities;
	private final Map<Term,Pair<Plan,Double>> minimalContribution;

	public SimpleStatisticsEstimator(SimpleCatalog catalog) {
		Preconditions.checkNotNull(catalog);
		this.catalog = catalog;
		this.inputCardinalities = new HashMap<>();
		this.outputCardinalities = new HashMap<>();
		this.minimalContribution = new HashMap<>();
	}

	@Override
	public void estimateStatistics(Plan plan) {
		if(plan instanceof DAGPlan) {
			this.estimateStatistics((DAGPlan)plan);
		}
		throw new java.lang.UnsupportedOperationException();
	}

	@Override
	public double getInputCardinality(Plan plan) {
		Preconditions.checkArgument(this.inputCardinalities.containsKey(plan));
		return this.inputCardinalities.get(plan);
	}

	@Override
	public double getOutputCardinality(Plan plan) {
		Preconditions.checkArgument(this.outputCardinalities.containsKey(plan));
		return this.outputCardinalities.get(plan);
	}

	@Override
	public double getERPSI(Plan plan) {
		return this.catalog.getERPSI(plan);
	}

	@Override
	public StatisticsEstimator clone() {
		return new SimpleStatisticsEstimator(this.catalog.clone());
	}
	
	public void estimateStatistics(DAGPlan plan) {
		Preconditions.checkArgument((this.outputCardinalities.containsKey(plan) && this.inputCardinalities.containsKey(plan)) ||
				(!this.outputCardinalities.containsKey(plan) && !this.inputCardinalities.containsKey(plan)));
		
		if(this.outputCardinalities.containsKey(plan) && this.inputCardinalities.containsKey(plan)) {
			return;
		}
		if(plan.getOperator() instanceof NaryOperator) {
			for(Plan child:plan.getChildren()) {
				this.estimateStatistics(child);
			}
			
			Preconditions.checkNotNull(plan.getChildren());
			Preconditions.checkArgument(plan.getChildren().size() == 2);
			Plan left = plan.getChildren().get(0);
			Plan right = plan.getChildren().get(1);
			
			double inputCardinality;
			double outputCardinality;
			if(plan.getOperator() instanceof DependentJoin) {
				inputCardinality = this.inputCardinalities.put(plan, this.outputCardinalities.get(left));
				outputCardinality = this.outputCardinalities.put(plan, this.outputCardinalities.get(right));
			}
			else if(plan.getOperator() instanceof Join) {
				inputCardinality = this.outputCardinalities.get(left) * this.outputCardinalities.get(right);
				outputCardinality = inputCardinality * this.catalog.getSelectivity(plan);
				this.inputCardinalities.put(plan, inputCardinality);
				this.outputCardinalities.put(plan, outputCardinality);
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			this.updateMinimalContribution(plan, outputCardinality);
		}
		else if(plan.getOperator() instanceof AccessOperator) {
			double inputCardinality = 1.0;
			for(Term input:plan.getOperator().getInputTerms()) {
				Pair<Plan, Double> contributor = this.minimalContribution.get(input);
				Preconditions.checkNotNull(contributor);
				inputCardinality *= this.outputCardinalities.get(contributor.getLeft());
			}
			double outputCardinality = this.getERPSI(plan) * inputCardinality;
			this.inputCardinalities.put(plan, inputCardinality);
			this.outputCardinalities.put(plan, outputCardinality);
			this.updateMinimalContribution(plan, outputCardinality);
		}
		else if(plan.getOperator() instanceof Selection) {
			Preconditions.checkNotNull(plan.getChildren());
			Preconditions.checkArgument(plan.getChildren().size() == 1);
			Plan left = plan.getChildren().get(0);
			double inputCardinality = this.outputCardinalities.get(left);
			double outputCardinality = inputCardinality * this.catalog.getSelectivity(plan);
			this.inputCardinalities.put(plan, inputCardinality);
			this.outputCardinalities.put(plan, outputCardinality);
			this.updateMinimalContribution(plan, outputCardinality);
		}
		else if(plan.getOperator() instanceof Projection) {
			Preconditions.checkNotNull(plan.getChildren());
			Preconditions.checkArgument(plan.getChildren().size() == 1);
			Plan left = plan.getChildren().get(0);
			double inputCardinality = this.outputCardinalities.get(left);
			double outputCardinality = inputCardinality;
			this.inputCardinalities.put(plan, inputCardinality);
			this.outputCardinalities.put(plan, outputCardinality);
			this.updateMinimalContribution(plan, outputCardinality);
		}
	}
	
	private void updateMinimalContribution(Plan plan, double outputCardinality) {
		for(Term column:plan.getOperator().getColumns()) {
			Pair<Plan, Double> contributor = this.minimalContribution.get(column);
			if(contributor == null || contributor.getRight() > outputCardinality) {
				 this.minimalContribution.put(column, Pair.of(plan, outputCardinality));
			}
		}
	}

}
