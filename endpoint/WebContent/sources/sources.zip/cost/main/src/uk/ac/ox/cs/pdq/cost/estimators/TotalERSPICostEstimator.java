package uk.ac.ox.cs.pdq.cost.estimators;

import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_COUNT;
import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_TIME;

import java.util.Collection;

import org.apache.log4j.Logger;

import uk.ac.ox.cs.pdq.cost.statistics.Catalog;
import uk.ac.ox.cs.pdq.logging.performance.StatisticsCollector;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.DoubleCost;
import uk.ac.ox.cs.pdq.plan.Plan;

import com.google.common.eventbus.EventBus;


/**
 * The cost of the plan equals the total number of output tuples per access 
 * @author Efthymia Tsamoura
 *
 */
public class TotalERSPICostEstimator<P extends Plan> implements SimpleCostEstimator<P>{
	
	protected final StatisticsCollector stats;
	
	private static Logger log = Logger.getLogger(TotalERSPICostEstimator.class);
	
	/** The database statistics */
	protected final Catalog catalog;
	
	/**
	 * 
	 * @param eventBus
	 * @param collectStats
	 * @param catalog
	 * 		The database statistics
	 */
	public TotalERSPICostEstimator(EventBus eventBus, boolean collectStats, Catalog catalog) {
		this(new StatisticsCollector(collectStats, eventBus), catalog);
	}
	
	/**
	 * 
	 * @param stats
	 * @param catalog
	 * 		The database statistics
	 */
	public TotalERSPICostEstimator(StatisticsCollector stats, Catalog catalog) {
		this.stats = stats;
		this.catalog = catalog;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public TotalERSPICostEstimator<P> clone() {
		return new TotalERSPICostEstimator<>(this.stats.clone(), this.catalog.clone());
	}
	
	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.costs.AbstractCostEstimator#cost(uk.ac.ox.cs.pdq.plan.Plan)
	 */
	@Override
	public DoubleCost cost(P plan) {
		DoubleCost result = this.cost(plan.getAccesses());
		plan.setCost(result);
		return result;
	}
	
	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.costs.AbstractCostEstimator#estimateCost(uk.ac.ox.cs.pdq.plan.Plan)
	 */
	@Override
	public DoubleCost estimateCost(P plan) {
		return this.cost(plan.getAccesses());
	}
	
	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.costs.AbstractCostEstimator#cost(Collection<AccessOperator>)
	 */
	@Override
	public DoubleCost cost(Collection<AccessOperator> accesses) {
		this.stats.start(COST_ESTIMATION_TIME);
		log.info(accesses);
		double totalCost = 0.0;
		for(AccessOperator access:accesses) {
			totalCost += this.catalog.getERPSI(access);
		}
		log.info(totalCost);
		this.stats.stop(COST_ESTIMATION_TIME);
		this.stats.increase(COST_ESTIMATION_COUNT, 1);
		return new DoubleCost(totalCost);
	}
}
