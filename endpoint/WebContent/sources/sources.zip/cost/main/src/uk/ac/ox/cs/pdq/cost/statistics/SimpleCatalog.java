package uk.ac.ox.cs.pdq.cost.statistics;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.tuple.Pair;
import org.apache.log4j.Logger;

import uk.ac.ox.cs.pdq.algebra.Join;
import uk.ac.ox.cs.pdq.algebra.Selection;
import uk.ac.ox.cs.pdq.algebra.predicates.AttributeEqualityPredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.ConjunctivePredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.ConstantEqualityPredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.Predicate;
import uk.ac.ox.cs.pdq.db.AccessMethod;
import uk.ac.ox.cs.pdq.db.Attribute;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.db.Schema;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.DAGPlan;
import uk.ac.ox.cs.pdq.plan.Plan;
import uk.ac.ox.cs.pdq.util.Operator;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;

/**
 * Holds unconditional statistics.
 * @author Efthymia Tsamoura
 *
 */
public class SimpleCatalog implements Catalog{
	
	/** Logger. */
	private static Logger log = Logger.getLogger(SimpleCatalog.class);

	private static int DEFAULT_CARDINALITY = 1000000;
	private static int DEFAULT_COLUMN_CARDINALITY = 1000;
	private static double DEFAULT_COST = 1.0;
	private static double DEFAULT_PER_TUPLE_RESPONSE_TIME = 1.0;
	private static String CATALOG_FILE_NAME = "catalog/catalog.properties";

	private static String READ_CARDINALITY = "^(RE:(\\w+)(\\s+)CA:(\\d+))";
	private static String READ_COLUMN_CARDINALITY = "^(RE:(\\w+)(\\s+)AT:(\\w+)(\\s+)CC:(\\d+))";
	private static String READ_COLUMN_SELECTIVITY = "^(RE:(\\w+)(\\s+)AT:(\\w+)(\\s+)SE:(\\d+(\\.\\d+)?))";
	private static String READ_ERSPI = "^(RE:(\\w+)(\\s+)BI:(\\w+)(\\s+)ERSPI:(\\d+(\\.\\d+)?))";
	private static String READ_RESPONSE_TIME = "^(RE:(\\w+)(\\s+)BI:(\\w+)(\\s+)RT:(\\d+(\\.\\d+)?))";

	/** Cardinalities of the schema relations*/
	private final Map<Relation,Integer> cardinalities;
	/** Cardinalities of the relations' attributes*/
	private final Map<Pair<Relation,Attribute>,Integer> columnCardinalities;
	/** The estimated result size per invocation of each access method*/
	private final Map<Pair<Relation,AccessMethod>,Double> erpsi;
	/** The response time of each access method*/
	private final Map<Pair<Relation,AccessMethod>,Double> responseTimes;
	/** The selectivity of each attribute*/
	private final Map<Pair<Relation,Attribute>,Double> columnSelectivity;


	/**
	 * 
	 * @param schema
	 */
	public SimpleCatalog(Schema schema) {
		this(schema, SimpleCatalog.CATALOG_FILE_NAME);
	}
	
	/**
	 * 
	 * @param schema
	 * @param fileName
	 */
	public SimpleCatalog(Schema schema, String fileName) {
		Preconditions.checkNotNull(schema);
		this.erpsi = new HashMap<>();
		this.responseTimes = new HashMap<>();
		this.columnSelectivity = new HashMap<>();
		this.cardinalities = new HashMap<>();
		this.columnCardinalities = new HashMap<>();
		this.read(schema, fileName);
	}

	/**
	 * 
	 * @param schema
	 * @param fileName
	 * 		The file that stores the statistics 
	 */
	private void read(Schema schema, String fileName) {
		String line = null;
		try {
			FileReader fileReader = new FileReader(fileName);//System.getProperty("user.home") + 
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while((line = bufferedReader.readLine()) != null) {
				this.parse(schema, line);
			}
			bufferedReader.close();            
		}
		catch(FileNotFoundException ex) {      
			ex.printStackTrace(System.out);
		}
		catch(IOException ex) {
			ex.printStackTrace(System.out);
		}
	}

	/**
	 * 
	 * @param schema
	 * @param line
	 */
	private void parse(Schema schema, String line) {
		log.info(line);
		Pattern p = Pattern.compile(READ_CARDINALITY);
		Matcher m = p.matcher(line);
		if (m.find()) {
			String relation = m.group(2);
			String cardinality = m.group(4);
			if(schema.contains(relation)) {
				Relation r = schema.getRelation(relation);
				this.cardinalities.put(r, Integer.parseInt(cardinality));
				log.info("RELATION: " + relation + " CARDINALITY: " + cardinality);
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			return;
		}

		p = Pattern.compile(READ_COLUMN_CARDINALITY);
		m = p.matcher(line);
		if (m.find()) {
			String relation = m.group(2);
			String column = m.group(4);
			String cardinality = m.group(6);
			if(schema.contains(relation)) {
				Relation r = schema.getRelation(relation);
				if(r.getAttribute(column) != null) {
					Attribute attribute = r.getAttribute(column);
					this.columnCardinalities.put( Pair.of(r,attribute), Integer.parseInt(cardinality));  
					log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " CARDINALITY: " + cardinality);
				}
				else {
					throw new java.lang.IllegalArgumentException();
				}
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			return;
		}

		p = Pattern.compile(READ_COLUMN_SELECTIVITY);
		m = p.matcher(line);
		if (m.find()) {
			String relation = m.group(2);
			String column = m.group(4);
			String selectivity = m.group(6);
			if(schema.contains(relation)) {
				Relation r = schema.getRelation(relation);
				if(r.getAttribute(column) != null) {
					Attribute attribute = r.getAttribute(column);
					this.columnSelectivity.put( Pair.of(r,attribute), Double.parseDouble(selectivity));  
					log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " SELECTIVITY: " + selectivity);
				}
				else {
					throw new java.lang.IllegalArgumentException();
				}
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			return;
		}

		p = Pattern.compile(READ_ERSPI);
		m = p.matcher(line);
		if (m.find()) {
			log.info(line);
			String relation = m.group(2);
			String binding = m.group(4);
			String erspi = m.group(6);
			if(schema.contains(relation)) {
				Relation r = schema.getRelation(relation);
				if(r.getAccessMethod(binding) != null) {
					AccessMethod b = r.getAccessMethod(binding);
					this.erpsi.put( Pair.of(r,b), Double.parseDouble(erspi));  
					log.info("RELATION: " + relation + " BINDING: " + binding + " ERPSI: " + erspi);
				}
				else {
					throw new java.lang.IllegalArgumentException();
				}
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			return;
		}

		p = Pattern.compile(READ_RESPONSE_TIME);
		m = p.matcher(line);
		if (m.find()) {
			String relation = m.group(2);
			String binding = m.group(4);
			String responseTime = m.group(6);
			if(schema.contains(relation)) {
				Relation r = schema.getRelation(relation);
				if(r.getAccessMethod(binding) != null) {
					AccessMethod b = r.getAccessMethod(binding);
					this.erpsi.put( Pair.of(r,b), Double.parseDouble(responseTime));  
					log.info("RELATION: " + relation + " BINDING: " + binding + " RESPONSE: " + responseTime);
				}
				else {
					throw new java.lang.IllegalArgumentException();
				}
			}
			else {
				throw new java.lang.IllegalArgumentException();
			}
			return;
		}
	}

	/**
	 * 
	 * @param cardinalities
	 * @param erpsi
	 * @param responseTimes
	 * @param columnSelectivity
	 * @param columnCardinalities
	 */
	private SimpleCatalog(Map<Relation,Integer> cardinalities, Map<Pair<Relation,AccessMethod>,Double> erpsi, Map<Pair<Relation,AccessMethod>,Double> responseTimes,
			Map<Pair<Relation,Attribute>,Double> columnSelectivity, Map<Pair<Relation,Attribute>,Integer> columnCardinalities) {
		Preconditions.checkNotNull(cardinalities);
		Preconditions.checkNotNull(erpsi);
		Preconditions.checkNotNull(responseTimes);
		Preconditions.checkNotNull(columnSelectivity);
		Preconditions.checkNotNull(columnCardinalities);
		this.cardinalities = Maps.newHashMap(cardinalities);
		this.erpsi = Maps.newHashMap(erpsi);
		this.responseTimes = Maps.newHashMap(responseTimes);
		this.columnSelectivity = Maps.newHashMap(columnSelectivity);
		this.columnCardinalities = Maps.newHashMap(columnCardinalities);
	}

	@Override
	public double getSelectivity(Plan plan) {
		return this.getSelectivity((DAGPlan)plan);
	}

	public double getSelectivity(DAGPlan plan) {
		Predicate predicate = null;
		if(plan.getOperator() instanceof Join) {
			Preconditions.checkArgument(plan.getChildren().size() == 2);
			predicate = ((Join)plan.getOperator()).getPredicate();
		}
		if(plan.getOperator() instanceof Selection) {
			Preconditions.checkArgument(plan.getChildren().size() == 1);
			predicate = ((Selection)plan.getOperator()).getPredicate();
		}

		if(predicate == null) {
			log.info("PLAN: " + plan + " SELECTIVITY: 1");
			return 1.0;
		}
		else {
			return this.getSelectivity(plan, predicate);
		}
	}

	/**
	 * 
	 * @param plan
	 * @param predicate
	 * @return
	 */
	@Override
	public double getSelectivity(Plan plan, Predicate predicate) {
		double selectivity = 1.0;
		if(predicate instanceof ConjunctivePredicate) {
			Iterator<?> iterator = ((ConjunctivePredicate<?>)predicate).iterator();
			while(iterator.hasNext()) {
				selectivity *= this.getSelectivity(plan, (Predicate) iterator.next());
			}
		}
		else {
			Collection<AccessOperator> accesses = plan.getAccesses();
			Iterator<AccessOperator> iterator = accesses.iterator();
			AccessOperator left = null;
			AccessOperator right = null;

			if(plan.getOperator() instanceof Selection) {
				Preconditions.checkState(accesses!= null && !accesses.isEmpty() && accesses.size() != 1);
				left = iterator.next();
				right = left;
			}
			else if(plan.getOperator() instanceof Join) {
				Preconditions.checkState(accesses!= null && !accesses.isEmpty() && accesses.size() != 2);
				left = iterator.next();
				right = iterator.next();
			}
			if(predicate instanceof ConstantEqualityPredicate) {
				return this.getSelectivity(left.getRelation(), (ConstantEqualityPredicate)predicate);
			}
			else if (predicate instanceof AttributeEqualityPredicate){
				return this.getSelectivity(left.getRelation(), right.getRelation(), (AttributeEqualityPredicate)predicate);
			}
			else {
				throw new java.lang.IllegalStateException();
			}
		}
		log.info("PLAN: " + plan + " PREDICATE: " + predicate + " SELECTIVITY: " + selectivity);
		return selectivity;
	}

	/**
	 * 
	 * @param predicate
	 * @param relation
	 * @return
	 */
	private double getSelectivity(Relation relation, ConstantEqualityPredicate predicate) {
		Attribute attribute = relation.getAttribute(predicate.getPosition());
		return this.getSelectivity(relation, attribute);
	}

	@Override
	public double getSelectivity(Relation relation, Attribute attribute) {
		Preconditions.checkNotNull(attribute);
		Preconditions.checkNotNull(relation);
		Double selectivities = this.columnSelectivity.get(Pair.of(relation, attribute));
		if(selectivities != null) {
			log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " SELECTIVITY: " + selectivities);
			return selectivities;
		}
		else {
			Integer columnCardinality = this.columnCardinalities.get(Pair.of(relation, attribute));
			if(columnCardinality != null) {
				log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " SELECTIVITY: " + 1.0/columnCardinality);
				return 1.0/columnCardinality;
			}
			log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " SELECTIVITY: " + 1.0/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY);
			return 1.0/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY;
		}
	}

	/**
	 * 
	 * @param predicate
	 * @param left
	 * @param right
	 * @return
	 */
	@Override
	public double getSelectivity(Relation left, Relation right, AttributeEqualityPredicate predicate) {
		Preconditions.checkNotNull(predicate);
		Preconditions.checkNotNull(left);
		Preconditions.checkNotNull(right);
		Attribute leftcolumn = left.getAttribute(predicate.getPosition());
		Attribute rightcolumn = right.getAttribute(predicate.getOther());
		Integer leftcardinalities = this.columnCardinalities.get(Pair.of(left, leftcolumn));
		Integer rightcardinalities = this.columnCardinalities.get(Pair.of(left, leftcolumn));
		if(leftcardinalities != null && rightcardinalities != null) {
			log.info("RELATION: " + left + " RELATION: " + right + " SELECTIVITY: " + 1.0 / Math.max(leftcardinalities, rightcardinalities));
			return 1.0 / Math.max(leftcardinalities, rightcardinalities);
		}
		else {
			log.info("RELATION: " + left + " RELATION: " + right + " SELECTIVITY: " + 1.0 / SimpleCatalog.DEFAULT_COLUMN_CARDINALITY);
			return 1.0 / SimpleCatalog.DEFAULT_COLUMN_CARDINALITY;
		}
	}

	@Override
	public double getCardinality(Relation relation) {
		Preconditions.checkNotNull(relation);
		if(this.cardinalities.containsKey(relation)) {
			log.info("RELATION: " + " CARDINALITY: " + this.cardinalities.get(relation));
			return this.cardinalities.get(relation);
		}
		log.info("RELATION: " + " CARDINALITY: " + SimpleCatalog.DEFAULT_CARDINALITY);
		return SimpleCatalog.DEFAULT_CARDINALITY;
	}

	@Override
	public double getCardinality(Relation relation, Attribute attribute) {
		Preconditions.checkNotNull(relation);
		Preconditions.checkNotNull(attribute);
		Integer columnCardinality = this.columnCardinalities.get(Pair.of(relation, attribute));
		if(columnCardinality != null) {
			log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " CARDINALITY: " + columnCardinality);
			return columnCardinality;
		}
		log.info("RELATION: " + relation + " ATTRIBUTE: " + attribute + " CARDINALITY: " + SimpleCatalog.DEFAULT_COLUMN_CARDINALITY);
		return SimpleCatalog.DEFAULT_COLUMN_CARDINALITY;
	}

	@Override
	public double getERPSI(Plan plan) {
		Operator operator = plan.getOperator();
		if(operator instanceof AccessOperator) {
			return this.getERPSI(((AccessOperator) operator).getRelation(), ((AccessOperator) operator).getBinding());
		}
		else {
			throw new java.lang.IllegalArgumentException();
		}
	}
	
	@Override
	public double getERPSI(AccessOperator access) {
		return this.getERPSI(access.getRelation(), access.getBinding());
	}
	
	public double getERPSI(Relation relation, AccessMethod binding) {
		Preconditions.checkNotNull(relation);
		Preconditions.checkNotNull(binding);
		Double erspi = this.erpsi.get(Pair.of(relation, binding));
		if(erspi == null) {
			double columnProduct = 1.0;
			for(Integer input:binding.getZeroBasedInputs()) {
				Attribute attribute = relation.getAttribute(input);
				Integer columnCardinality = this.columnCardinalities.get(Pair.of(relation, attribute));
				if(columnCardinality != null) {
					columnProduct *= columnCardinality;
				}
				else {
					log.info("RELATION: " + relation + " AccessMethod: " + binding + " ERPSI: " + SimpleCatalog.DEFAULT_CARDINALITY/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY);
					return SimpleCatalog.DEFAULT_CARDINALITY/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY;
				}
			}
			if(this.cardinalities.containsKey(relation)) {
				log.info("RELATION: " + relation + " AccessMethod: " + binding + " ERPSI: " + this.cardinalities.get(relation)/columnProduct);
				return this.cardinalities.get(relation)/columnProduct;
			}
			else {
				log.info("RELATION: " + relation + " AccessMethod: " + binding + " ERPSI: " + SimpleCatalog.DEFAULT_CARDINALITY/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY);
				return SimpleCatalog.DEFAULT_CARDINALITY/SimpleCatalog.DEFAULT_COLUMN_CARDINALITY;
			}
		}
		return erspi;
	}
	
	public Map<Pair<Relation, AccessMethod>, Double> getERPSI() {
		return this.erpsi;
	}


	@Override
	public double getResponseTime(Plan plan) {
		Operator operator = plan.getOperator();
		if(operator instanceof AccessOperator) {
			return this.getResponseTime(((AccessOperator) operator).getRelation(), ((AccessOperator) operator).getBinding());
		}
		else {
			throw new java.lang.IllegalArgumentException();
		}
	}
	
	public double getResponseTime(Relation relation, AccessMethod binding) {
		Preconditions.checkNotNull(relation);
		Preconditions.checkNotNull(binding);
		Double responseTime = this.responseTimes.get(Pair.of(relation, binding));
		if(responseTime == null) {
			return this.getERPSI(relation, binding) * SimpleCatalog.DEFAULT_PER_TUPLE_RESPONSE_TIME;
		}
		return responseTime;

	}

	@Override
	public double getCost(Plan plan) {
		return SimpleCatalog.DEFAULT_COST;
	}

	@Override
	public SimpleCatalog clone() {
		return new SimpleCatalog(this.cardinalities, this.erpsi, this.responseTimes, this.columnSelectivity, this.columnCardinalities);
	}

}
