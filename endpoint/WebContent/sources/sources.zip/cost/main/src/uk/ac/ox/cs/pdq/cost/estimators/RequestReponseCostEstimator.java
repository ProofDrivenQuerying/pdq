package uk.ac.ox.cs.pdq.cost.estimators;

import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_COUNT;
import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_TIME;
import uk.ac.ox.cs.pdq.cost.statistics.estimators.StatisticsEstimator;
import uk.ac.ox.cs.pdq.logging.performance.StatisticsCollector;
import uk.ac.ox.cs.pdq.plan.Cost;
import uk.ac.ox.cs.pdq.plan.DAGPlan;
import uk.ac.ox.cs.pdq.plan.DoubleCost;
import uk.ac.ox.cs.pdq.plan.Plan;
import uk.ac.ox.cs.pdq.plan.Plan.ControlFlows;

import com.google.common.eventbus.EventBus;


/**
 * 
 * @author Efthymia Tsamoura
 *
 */
public class RequestReponseCostEstimator<P extends Plan> implements BlackBoxCostEstimator<P> {
	
	protected final StatisticsCollector stats;
	
	protected final StatisticsEstimator statisticsEstimator;
	
	/**
	 * Default constructor
	 * @param eventBus
	 * @param collectStats
	 */
	public RequestReponseCostEstimator(EventBus eventBus, boolean collectStats, StatisticsEstimator statisticsEstimator) {
		this(new StatisticsCollector(collectStats, eventBus), statisticsEstimator);
	}
	
	/**
	 * Constructor
	 * @param stats
	 */
	public RequestReponseCostEstimator(StatisticsCollector stats, StatisticsEstimator statisticsEstimator) {
		this.stats = stats;
		this.statisticsEstimator = statisticsEstimator;
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public RequestReponseCostEstimator<P> clone() {
		return new RequestReponseCostEstimator<>(this.stats.clone(), this.statisticsEstimator.clone());
	}

	public StatisticsEstimator getStatisticsEstimator() {
		return this.statisticsEstimator;
	}
	
	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.costs.AbstractCostEstimator#cost(uk.ac.ox.cs.pdq.plan.Plan)
	 */
	@Override
	public Cost cost(P plan) {
		plan.setCost(this.estimateCost(plan));
		return plan.getCost();
	}
	
	/**
	 * Recursively computes the cost of the given plan.
	 * @param plan
	 * @return the cost of the given plan.
	 */
	private double recursiveCost(P plan) {
		if (plan instanceof DAGPlan) {
			DAGPlan dPlan = (DAGPlan) plan;
			ControlFlows cf = plan.getControlFlow();
			if (cf == ControlFlows.BOTTOM_UP) {
				throw new java.lang.UnsupportedOperationException();
			}
			if (!dPlan.isClosed()) {
				return Double.POSITIVE_INFINITY;
			}
		} 
		
		this.statisticsEstimator.estimateStatistics(plan);
		double cost = 0.0;
		//TODO Implement
//		Collection<Plan> accesses = plan.getAccessPlans();
//		for(Plan access:accesses) {
//			cost += this.statisticsEstimator.getInputCardinality(access) * this.statisticsEstimator.getERPSI(access);
//		}
		return cost;
	}

	@Override
	public Cost estimateCost(P plan) {
		this.stats.start(COST_ESTIMATION_TIME);
		DoubleCost result = new DoubleCost(this.recursiveCost(plan));
		this.stats.stop(COST_ESTIMATION_TIME);
		this.stats.increase(COST_ESTIMATION_COUNT, 1);
		return result;
	}
}
