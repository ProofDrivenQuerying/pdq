package uk.ac.ox.cs.pdq.cost.estimators;

import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_COUNT;
import static uk.ac.ox.cs.pdq.logging.performance.StatKeys.COST_ESTIMATION_TIME;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import uk.ac.ox.cs.pdq.algebra.Access;
import uk.ac.ox.cs.pdq.algebra.Count;
import uk.ac.ox.cs.pdq.algebra.DependentJoin;
import uk.ac.ox.cs.pdq.algebra.IsEmpty;
import uk.ac.ox.cs.pdq.algebra.Join;
import uk.ac.ox.cs.pdq.algebra.NaryOperator;
import uk.ac.ox.cs.pdq.algebra.PredicateBasedOperator;
import uk.ac.ox.cs.pdq.algebra.Projection;
import uk.ac.ox.cs.pdq.algebra.RelationalOperator;
import uk.ac.ox.cs.pdq.algebra.StaticInput;
import uk.ac.ox.cs.pdq.algebra.SubPlanAlias;
import uk.ac.ox.cs.pdq.algebra.UnaryOperator;
import uk.ac.ox.cs.pdq.algebra.predicates.ConjunctivePredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.Predicate;
import uk.ac.ox.cs.pdq.cost.statistics.estimators.CardinalityEstimator;
import uk.ac.ox.cs.pdq.cost.statistics.estimators.PlanCostIndex;
import uk.ac.ox.cs.pdq.db.AccessMethod.AccessMethodTypes;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.logging.performance.StatisticsCollector;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.Cost;
import uk.ac.ox.cs.pdq.plan.DAGPlan;
import uk.ac.ox.cs.pdq.plan.DoubleCost;
import uk.ac.ox.cs.pdq.plan.LinearPlan;
import uk.ac.ox.cs.pdq.plan.Plan;
import uk.ac.ox.cs.pdq.plan.Plan.ControlFlows;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.SortedMultiset;
import com.google.common.eventbus.EventBus;


/**
 * A whitebox cost estimation implementation.
 * According to this, the cost of a plan equals the number of the accesses.
 * Based on cost estimation as defined in the "Database Management System" by
 * Ramakrishnan and Gehrke.
 *
 * Roughly speaking, the cost of a plan is the sum of the cost of its sub-plans,
 * plus it own IO cost multiple by an estimation of its cardinality.
 *
 * @author Julien Leblay
 *
 */
public class WhiteBoxCostEstimator<P extends Plan> implements BlackBoxCostEstimator<P>{

	protected final StatisticsCollector stats;
	
	protected PlanCostIndex planIndex = new PlanCostIndex();

	protected final CardinalityEstimator cardEstimator;

	/**
	 * Default constructor
	 * @param eventBus
	 * @param collectStats
	 * @param ce CardinalityEstimator
	 */
	public WhiteBoxCostEstimator(EventBus eventBus, boolean collectStats, CardinalityEstimator ce) {
		this(new StatisticsCollector(collectStats, eventBus), ce);
	}

	/**
	 * Constructor
	 * @param stats
	 * @param ce CardinalityEstimator
	 */
	public WhiteBoxCostEstimator(StatisticsCollector stats, CardinalityEstimator ce) {
		this.stats = stats;
		this.cardEstimator = ce;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public WhiteBoxCostEstimator<P> clone() {
		return new WhiteBoxCostEstimator<>(this.stats.clone(), this.cardEstimator.clone());
	}

	/**
	 * @return CardinalityEstimator
	 */
	public CardinalityEstimator getCardinalityEstimator() {
		return this.cardEstimator;
	}

	/**
	 * Recursively computes the cost of the given plan.
	 * @param plan
	 * @return the cost of the given plan.
	 */
	private double recursiveCost(P plan) {
		if (plan instanceof DAGPlan) {
			DAGPlan dPlan = (DAGPlan) plan;
			ControlFlows cf = plan.getControlFlow();
			if (cf == ControlFlows.BOTTOM_UP) {
				this.assignAliases(dPlan);
			}
			if (!dPlan.isClosed()) {
				return Double.POSITIVE_INFINITY;
			}
			RelationalOperator lo = plan.getOperator();
			this.cardEstimator.estimate(lo);
			return this.recursiveCost(lo, dPlan.getDescendants());
		} else if (plan instanceof LinearPlan) {
			RelationalOperator lo = plan.getOperator();
			this.cardEstimator.estimate(lo);
			return this.recursiveCost(lo);
		}
		throw new IllegalStateException("Unknown plan type " + plan);
	}

	/**
	 * @param p DAGPlan
	 */
	private void assignAliases(DAGPlan p) {
		for (AccessOperator access: p.getAccesses()) {
			if (access instanceof Access
					&& access.getBinding().getType() != AccessMethodTypes.FREE) {
				SubPlanAlias alias = ((SubPlanAlias) ((Projection) ((Access) access).getChild()).getChild());
				// To avoid cycles
				SortedMultiset<DAGPlan> subPlans = this.planIndex.getAll(Sets.newHashSet(alias.getColumns()));
				for (DAGPlan subPlan : subPlans) {
					if (!Utility.containsElement(subPlan.getAccesses(), p.getAccesses())) {
						alias.setPlan(subPlan);
						break;
					}
				}
			}
		}
	}

	/**
	 * Recursively computes the cost of the given operator, assuming an empty
	 * descendant collection and an input cardinality of 0.
	 * @param logOp
	 * @return the cost of the given operator.
	 */
	public double recursiveCost(RelationalOperator logOp) {
		return this.recursiveCost(logOp, Lists.<DAGPlan>newArrayList());
	}

	/**
	 * Recursively computes the cost of the given operator.
	 * @param logOp
	 * @param descendants
	 * @return the cost of the given operator.
	 */
	private double recursiveCost(RelationalOperator logOp, Collection<DAGPlan> descendants) {
		if (descendants != null) {
			for (DAGPlan child: descendants) {
				if (child.getOperator().equals(logOp)) {
					Double result = (Double) child.getCost().getValue();
					if (result != Double.POSITIVE_INFINITY) {
						return result;
					}
				}
			}
		}

		double subCost = 0;
		double inputCard = logOp.getMetadata().getInputCardinality();
		double card = Math.max(1.0, logOp.getMetadata().getOutputCardinality());
		double localCost =
				Math.max(0.0, card * perOutputTupleCost(logOp));
		//		if (logOp instanceof AccessOperator) {
		//			localCost += Math.max(1.0, inputCard) * perInputTupleCost(logOp);
		//		}
		if (logOp instanceof SubPlanAlias) {
			Plan subPlan = ((SubPlanAlias) logOp).getPlan();
			Cost aliasCost = new DoubleCost(Double.POSITIVE_INFINITY);
			if (subPlan != null) {
				aliasCost = subPlan.getCost();
				if (aliasCost == null || aliasCost.isUpperBound()) {
					aliasCost = new DoubleCost(this.recursiveCost((RelationalOperator) subPlan.getOperator()));
				}
				subPlan.setCost(aliasCost);
			}
			return aliasCost.getValue().doubleValue();

		} else if (logOp instanceof UnaryOperator) {
			RelationalOperator child = ((UnaryOperator) logOp).getChild();
			if (logOp instanceof Access) {
				if (child != null) {
					localCost *= Math.max(1.0, Math.log(child.getMetadata().getOutputCardinality()));
				} else {
					return Double.POSITIVE_INFINITY;
				}
			}
			subCost = this.recursiveCost(child, descendants);

		} else if (logOp instanceof NaryOperator) {
			int interCard = 1;
			if (logOp instanceof DependentJoin) {
				RelationalOperator leftOp = ((DependentJoin) logOp).getLeft();
				subCost += this.recursiveCost(leftOp, descendants);
				double leftInputCard = leftOp.getMetadata().getOutputCardinality();
				double rSubCost = this.recursiveCost(((DependentJoin) logOp).getRight(), descendants);
				subCost += Math.max(rSubCost, (rSubCost / Math.max(1.0, inputCard)) * leftInputCard);
			} else {
				for (RelationalOperator child: ((NaryOperator) logOp).getChildren()) {
					if (logOp instanceof Join && ((Join) logOp).hasPredicate()) {
						switch (((Join) logOp).getVariant()) {
						case ASYMMETRIC_HASH:
						case SYMMETRIC_HASH:
						case MERGE:
							subCost += this.recursiveCost(child, descendants);
							continue;
						}
					}
					subCost += interCard * this.recursiveCost(child, descendants);
					interCard *= Math.max(1.0, child.getMetadata().getOutputCardinality());
				}
			}
		}
		return subCost + localCost;
	}

	/**
	 * @param o
	 * @return the per-output tuple I/O cost of the given operator.
	 */
	private static Double perOutputTupleCost(RelationalOperator o) {
		if (o instanceof PredicateBasedOperator) {
			Predicate predicate = ((PredicateBasedOperator) o).getPredicate();
			if (predicate instanceof ConjunctivePredicate) {
				return (double) ((ConjunctivePredicate) predicate).size();
			}
			return 1.0;
		}
		if (o instanceof Projection) {
			Projection p = ((Projection) o);
			RelationalOperator child = p.getChild();
			List<Term> projected = p.getColumns();
			Map<Integer, Term> renaming = p.getRenaming();
			if (renaming != null && projected.equals(child.getColumns())) {
				return 1.0;
			}
			return (projected.size() / (double) child.getColumns().size());
		}
		if (o instanceof SubPlanAlias) {
			Plan subPlan = ((SubPlanAlias) o).getPlan();
			if (subPlan != null) {
				return perOutputTupleCost((RelationalOperator) subPlan.getOperator());
			}
			return null;
		}
		if (o instanceof Count || o instanceof IsEmpty) {
			return 1.0;
		}
		if (o instanceof StaticInput) {
			return 0.0;
		}
		return (double) o.getColumns().size();
	}

	@Override
	public Cost estimateCost(P plan) {
		this.stats.start(COST_ESTIMATION_TIME);
		DoubleCost result = new DoubleCost(this.recursiveCost(plan));
		this.stats.stop(COST_ESTIMATION_TIME);
		this.stats.increase(COST_ESTIMATION_COUNT, 1);
		if (plan.getControlFlow() == ControlFlows.BOTTOM_UP) {
			this.planIndex.update((DAGPlan) plan);
		}
		return result;
	}
	
	/**
	 * @param plan P
	 * @return DoubleCost
	 * @see uk.ac.ox.cs.pdq.cost.estimators.CostEstimator#cost(P)
	 */
	@Override
	public Cost cost(P plan) {
		plan.setCost(this.estimateCost(plan));
		return plan.getCost();
	}
}
