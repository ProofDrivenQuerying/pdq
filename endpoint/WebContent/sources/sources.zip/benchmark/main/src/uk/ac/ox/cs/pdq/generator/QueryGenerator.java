package uk.ac.ox.cs.pdq.generator;

import uk.ac.ox.cs.pdq.fol.ConjunctiveQuery;

/**
 * 
 * @author Efthymia Tsamoura
 *
 */
public interface QueryGenerator {
	ConjunctiveQuery generate();
}
