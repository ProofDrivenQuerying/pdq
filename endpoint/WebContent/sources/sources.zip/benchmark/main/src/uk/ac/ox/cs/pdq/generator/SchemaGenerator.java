package uk.ac.ox.cs.pdq.generator;

import uk.ac.ox.cs.pdq.db.Schema;


/**
 * 
 * @author Efthymia Tsamoura
 *
 */
public interface SchemaGenerator {
	Schema generate();
}
