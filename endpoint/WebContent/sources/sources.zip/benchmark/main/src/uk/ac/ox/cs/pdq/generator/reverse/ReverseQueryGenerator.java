package uk.ac.ox.cs.pdq.generator.reverse;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import uk.ac.ox.cs.pdq.db.Schema;
import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.fol.ConjunctiveQuery;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Query;
import uk.ac.ox.cs.pdq.io.xml.QueryReader;
import uk.ac.ox.cs.pdq.io.xml.SchemaReader;
import uk.ac.ox.cs.pdq.planner.PlannerParameters;
import uk.ac.ox.cs.pdq.planner.db.access.AccessibleSchema;
import uk.ac.ox.cs.pdq.planner.db.access.AccessibleSchema.AccessibleRelation;
import uk.ac.ox.cs.pdq.planner.homomorphism.HomomorphismDetector;
import uk.ac.ox.cs.pdq.planner.homomorphism.HomomorphismManagerFactory;
import uk.ac.ox.cs.pdq.planner.reasoning.chase.ReasonerFactory;
import uk.ac.ox.cs.pdq.planner.reasoning.chase.state.ChaseState;
import uk.ac.ox.cs.pdq.planner.reasoning.chase.state.StateFactory;
import uk.ac.ox.cs.pdq.reasoning.Reasoner;

import com.google.common.collect.Iterables;
import com.google.common.eventbus.EventBus;

public class ReverseQueryGenerator implements Runnable {

	/** Logger. */
	private static Logger log = Logger.getLogger(ReverseQueryGenerator.class);

	private static Integer seeds = 0;

	private final Integer threadId;
	private final Schema schema;
	private final ConjunctiveQuery query;

	private Integer done = 0;
	
	public ReverseQueryGenerator(Integer threadId, Schema schema, ConjunctiveQuery query) {
		this.threadId = threadId;
		this.schema = schema;
		this.query = query;
	}

	public static synchronized Integer getSeed() {
		return seeds++;
	}

	@Override
	public void run() {
		try {
			PlannerParameters params = new PlannerParameters();
			this.schema.updateConstantsMap(this.query.getSchemaConstants());
			AccessibleSchema accessibleSchema = new AccessibleSchema(this.schema);
			EventBus eb = new EventBus();
			Reasoner reasoner = new ReasonerFactory(
					eb, true, 
					this.schema,
					accessibleSchema,
					this.query, params).getInstance(); 
			MatchMaker mm = new MatchMaker(
					new LengthBasedQuerySelector(2, 6),
					new ConstantRatioQuerySelector(0.2),
					new CrossProductFreeQuerySelector(),
					new NoAllFreeAccessQuerySelector(),
					new DubiousRepeatedPredicateQuerySelector(),
					new JoinOnVariableQuerySelector(),
					new DiversityQuerySelector()
//					new UnanswerableQuerySelector(params, this.schema)
					);
			eb.register(mm);
			Runtime.getRuntime().addShutdownHook(new MatchReport(mm));

			Query<?> accessibleQuery = accessibleSchema.accessible(this.query);
			try(HomomorphismDetector detector =
				HomomorphismManagerFactory.getInstance(accessibleSchema, accessibleQuery, params)) {
				ChaseState state = StateFactory.getInstance(
						null, detector,
						createInitialisationFormula(this.schema, this.query));
				log.info("Phase 1");
				reasoner.fixpoint(state, Iterables.concat(this.schema.getDependencies()));
				log.info("Phase 2");
				reasoner.fixpoint(state, Iterables.concat(
						accessibleSchema.getFastAccessibilityAxioms(),
						accessibleSchema.getShortInferredAccessibilityAxioms()));
				log.info("Reasoning complete.");
		}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static Collection<PredicateFormula> createInitialisationFormula(Schema s, Query<?> q) {
		Collection<PredicateFormula> initFormula = q.getCanonicalQuery().getPredicates();
		for (TypedConstant<?> constant : Iterables.concat(q.getSchemaConstants(), s.getDependencyConstants())) {
			initFormula.add(AccessibleRelation.getAccessibleFact(constant));
		}
		return initFormula;
	}

	public static void main(String... args) {
		long timeout = 120000;
		try(FileInputStream fis = new FileInputStream("../pdq.benchmark/test/dag/web/schemas/schema-all.xml");
			FileInputStream qis = new FileInputStream("../pdq.benchmark/test/dag/web/queries/query-all.xml")) {
			Schema schema = new SchemaReader().read(fis);
			ConjunctiveQuery query = new QueryReader(schema).read(qis);
			ExecutorService exec = Executors.newFixedThreadPool(2);
			exec.submit(new ReverseQueryGenerator(1, schema, query));
			exec.submit(new ShowStopper(timeout));
			exec.shutdown();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Report the finding of a MatchMaker
	 * 
	 * @author Julien Leblay
	 */
	public static class MatchReport extends Thread {

		private final MatchMaker mm;

		public MatchReport(MatchMaker mm) {
			this.mm = mm;
		}
		
		@Override
		public void run() {
			this.mm.report();
		}
	}
		
	
	/**
	 * This is aimed at forcing the end of a test, thus by-passing the internal 
	 * search timeout mechanism.
	 * 
	 * @author Julien Leblay
	 *
	 */
	public static class ShowStopper extends Thread {
	
		private long timeout = -1L;
		
		public ShowStopper(long timeout) {
			this.setDaemon(true);
			this.timeout = timeout;
		}
		
		@Override
		public void run() {
			if (this.timeout > 0l) {
				try {
					Thread.sleep(this.timeout);
					Runtime.getRuntime().exit(-1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
