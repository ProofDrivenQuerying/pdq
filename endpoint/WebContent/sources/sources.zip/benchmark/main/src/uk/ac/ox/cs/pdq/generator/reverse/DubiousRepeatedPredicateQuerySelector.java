package uk.ac.ox.cs.pdq.generator.reverse;

import java.util.Collections;
import java.util.List;

import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Query;

import com.google.common.collect.Lists;

/**
 * A QuerySelector that accepts only conjunctive query where no two predicate
 * have the same name and their sequence of constants cover one another.
 * 
 * @author Julien Leblay
 *
 */
public class DubiousRepeatedPredicateQuerySelector implements QuerySelector {

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.builder.generator.reverse.QuerySelector#accept(uk.ac.ox.cs.pdq.formula.Query)
	 */
	@Override
	public boolean accept(Query<?> q) {
		List<PredicateFormula> list = Lists.newArrayList(q.getBody().getPredicates());
		for (int i = 0, k = list.size(); i < k - 1; i++) {
			PredicateFormula p1 = list.get(i);
			FactSignature s1 = FactSignature.make(p1);
			for (int j = i + 1, l = list.size(); j < l; j++) {
				PredicateFormula p2 = list.get(j);
				FactSignature s2 = FactSignature.make(p2);
				if (s1.covers(s2) || s2.covers(s1)) {
					return false;
				}
				if (p2.getPredicateName().equals(p1.getPredicateName())
					&& !Collections.disjoint(list.get(i).getTerms(), list.get(j).getTerms())) {
					return false;
				}
			}
		}
		return true;
	}

}
