package uk.ac.ox.cs.pdq.benchmark;

import java.io.FileInputStream;
import java.io.IOException;

import uk.ac.ox.cs.pdq.db.Schema;
import uk.ac.ox.cs.pdq.io.xml.SchemaReader;

public class SchemaLoadingTimeChecker {
	
	public static void main(String... args) {
		try (
				FileInputStream f1 = new FileInputStream("test/dag/tpch/postgresql/algorithm/4/throttling/depth/3/followups/maximal/contro_flow/top_down/cost_function/blackbox/tpch_0001/schemas/fk_inputs/queries/std_006/schema.xml");
				FileInputStream f2 = new FileInputStream("test/dag/tpch/postgresql/algorithm/4/throttling/depth/3/followups/maximal/contro_flow/top_down/cost_function/blackbox/tpch_001/schemas/fk_inputs/queries/std_006/schema.xml");
				FileInputStream f3 = new FileInputStream("test/dag/tpch/postgresql/algorithm/4/throttling/depth/3/followups/maximal/contro_flow/top_down/cost_function/blackbox/tpch_01/schemas/fk_inputs/queries/std_006/schema.xml");
				FileInputStream f4 = new FileInputStream("test/dag/tpch/postgresql/algorithm/4/throttling/depth/3/followups/maximal/contro_flow/top_down/cost_function/blackbox/tpch_1/schemas/fk_inputs/queries/std_006/schema.xml");
				) {
			long start = System.currentTimeMillis();
			Schema s = new SchemaReader().read(f1);
			System.out.println(System.currentTimeMillis() - start);

			start = System.currentTimeMillis();
			s = new SchemaReader().read(f2);
			System.out.println(System.currentTimeMillis() - start);

			start = System.currentTimeMillis();
			s = new SchemaReader().read(f3);
			System.out.println(System.currentTimeMillis() - start);

			start = System.currentTimeMillis();
			s = new SchemaReader().read(f4);
			System.out.println(System.currentTimeMillis() - start);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
