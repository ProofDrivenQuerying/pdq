package uk.ac.ox.cs.pdq.generator.reverse;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import uk.ac.ox.cs.pdq.fol.Conjunction;
import uk.ac.ox.cs.pdq.fol.Formula;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Query;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.base.Preconditions;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;

/**
 * A QuerySelector that accept only conjunctive queries without cross products.
 * 
 * @author Julien Leblay
 */
public class CrossProductFreeQuerySelector implements QuerySelector {

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.builder.generator.reverse.QuerySelector#accept(uk.ac.ox.cs.pdq.formula.Query)
	 */
	@Override
	public boolean accept(Query<?> q) {
		for (Conjunction<PredicateFormula> body : this.enumerateConjunctions(q.getBody())) {
			if (body.size() > 1) {
				Multimap<Term, PredicateFormula> clusters = LinkedHashMultimap.create();
				for (PredicateFormula pred: body) {
					for (Term t: pred.getTerms()) {
						clusters.put(t, pred);
					}
				}
				List<Set<PredicateFormula>> localClusters2 = new LinkedList<>();
				for (Term t: clusters.keySet()) {
					localClusters2.add(Sets.newHashSet(clusters.get(t)));
				}
				return Utility.connectedComponents(localClusters2).size() == 1;
			}
		}
		return true;
	}

	private Collection<Conjunction<PredicateFormula>> enumerateConjunctions(Formula formula) {
		Preconditions.checkArgument(formula != null);
		if (formula instanceof Conjunction) {
			List<Conjunction<PredicateFormula>> result = new LinkedList<>();
			List<PredicateFormula> localConj = new LinkedList<>();
			for (Formula subFormula: ((Conjunction<Formula>) formula)) {
				if (subFormula instanceof PredicateFormula) {
					localConj.add((PredicateFormula) subFormula);
				} else {
					result.addAll(this.enumerateConjunctions(subFormula));
				}
			}
			result.add(Conjunction.of(localConj));
			return result;
		}
		throw new IllegalStateException();
	}
}
