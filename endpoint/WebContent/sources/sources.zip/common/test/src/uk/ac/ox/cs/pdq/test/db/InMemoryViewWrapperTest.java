package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * 
 * @author Julien Leblay
 */
public class InMemoryViewWrapperTest {

	@Test public void load() {
	}

	@Test public void clear() {
	}
	
	@Test public void getData() {
	}
	
	@Test public void access() {
	}


	@Test public void getProperties() {
	}

	@Test public void iterator2() {
	}

	@Test public void  iterator() {
	}


	@Test public void accessIteratorOpen() {
	}

	@Test public void accessIteratorRest() {
	}

	@Test public void accessIteratorDeepCopy() {
	}
		
	@Test public void accessIteratorHasNext() {
	}

	@Test public void accessIteratorNext() {
	}
		
	@Test public void accessIteratorNextTuple() {
	}
		
	@Test public void accessIteratorRemove() {
	}
}
