package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class SchemaTest {

	@Test
	public void testSchemaTest1() {
	}

	@Test
	public void testSchemaTest2() {
	}

	@Test
	public void testSchemaTest3() {
	}

	@Test
	public void getViews() {
	}

	@Test
	public void containsViews() {
	}

	@Test
	public void getRelationsByArity() {
	}

	@Test
	public void getRelations() {
	}

	@Test
	public void getRelationsMap() {
	}

	@Test
	public void getMaxArity() {
	}

	@Test
	public void getDependencies() {
	}

	@Test
	public void getRelation() {
	}

	@Test
	public void isCyclic() {
	}

	@Test
	public void getDependencyConstants() {
	}

	@Test
	public void updateConstantsMap() {
	}

	@Test
	public void getConstantsMap() {
	}

	@Test
	public void getConstants() {
	}

	@Test
	public void containsRelation() {
	}

	@Test
	public void containsIC() {
	}

	@Test
	public void testEquals() {
	}

	@Test
	public void testHashCode() {
	}

	@Test
	public void builder() {
	}

	@Test
	public void Builder() {
	}

	@Test
	public void testBuilderaddRelation() {
	}

	@Test
	public void testBuilderAddRelation() {
	}

	@Test
	public void testBuilderAaddDependency() {
	}

	@Test
	public void testBuilderRemoveDependency() {
	}

	@Test
	public void testBuilderAddDependencies() {
	}

	@Test
	public void testBuilderDisableDependencies() {
	}

	@Test
	public void testBuilderAddRelations() {
	}

	@Test
	public void testBuilderAddSchema() {
	}

	@Test
	public void testBuilderGetRelation() {
	}

	@Test
	public void testBuilderGetRelations() {
	}

	@Test
	public void testBuilderGetRelationMap() {
	}

	@Test
	public void testBuilderGetDependencies() {
	}

	@Test
	public void testBuilderBuild() {
	}

	@Test
	public void testGetReachableRelations() {
	}
}
