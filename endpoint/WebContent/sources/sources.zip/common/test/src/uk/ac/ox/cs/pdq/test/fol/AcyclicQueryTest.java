package uk.ac.ox.cs.pdq.test.fol;

import org.junit.Test;


/**
 * @author Julien Leblay
 */
public class AcyclicQueryTest {

	@Test public void getSuffixQueries() {
	}

	@Test public void getLastQuery() {
	}
}
