package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class AccessibleSchemaTest {

	@Test public void testAccessibleSchemaTest2() {
	}

	@Test public void testAccessibleSchemaTest1() {
	}

	@Test public void testGetInferredAccessibilityAxioms() {
	}

	@Test public void getShortInferredAccessibilityAxioms() {
	}

	@Test public void getInferredAccessibleViews() {
	}

	@Test public void getAccessibilityAxioms() {
	}

	@Test public void getFastAccessibilityAxioms() {
	}

	@Test public void getDefiningAxioms() {
	}

	@Test public void getRelationsMap() {
	}

	@Test public void getRelations() {
	}

	@Test public void getRelation() {
	}

	@Test public void getAccessibleRelation() {
	}

	@Test public void getAccessedRelation() {
	}

	@Test public void getInferredAccessibleRelation() {
	}

	@Test public void testContainsRelation() {
	}

	@Test public void testContainsIC() {
	}

	@Test public void getDependencies() {
	}

	@Test public void getDefiningAxioms2() {
	}

	@Test public void getAccessibilityAxiom() {
	}

	@Test public void getInferredAccAxiom2() {
	}

	@Test public void getInferredAccAxiom3() {
	}

	@Test public void staticBindingPositions() {
	}

	@Test public void testAccessedRelation1() {
	}

	@Test public void testAccessedRelation2() {
	}

	@Test public void testAccessedRelationGetBaseRelation() {
	}

	@Test public void staticTestAccessedRelationGetAccessibleFact() {
	}

	@Test public void staticTestAccessedRelationGetInstance() {
	}

	@Test public void testInferredAccessibleRelation1() {
	}

	@Test public void testInferredAccessibleRelation2() {
	}

	@Test public void testInferredAccessibleGetBaseRelation() {
	}
}
