package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 *
 * @param <N>
 */
public class PlanTreeTest {

	@Test public void PlanTree1() {
	}

	@Test public void PlanTree2() {
	}

	@Test public void addVertex() {
	}

	@Test public void getVertex() {
	}

	@Test public void getRoot() {
	}
}
