package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class TypedConstantTest {

	@Test public void testTypedConstant1() {
	}

	@Test public void testTypedConstant2() {
	}

	@Test public void testGetType() {
	}

	@Test public void testGetValue() {
	}

	@Test public void equals() {
	}

	@Test public void isVariable() {
	}

	@Test public void isSkolem() {
	}
}
