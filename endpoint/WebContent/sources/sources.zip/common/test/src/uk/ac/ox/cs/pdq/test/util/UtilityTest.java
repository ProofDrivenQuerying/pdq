package uk.ac.ox.cs.pdq.test.util;

import org.junit.Test;

/**
 * Utilit unit test
 *
 * @author Julien Leblay
 *
 */
public class UtilityTest {


	@Test public void search() {
	}

	@Test public void containsElement() {
	}

	@Test public void removeDuplicates() {
	}

	@Test public void extract() {
	}

	@Test public void typedToTerms() {
	}

	@Test public void typedToTerm() {
	}

	@Test public void getTypedConstants() {
	}

	@Test public void typedToVariableTerms() {
	}

	@Test public void getVariables() {
	}

	@Test public void getConstantsCollection() {
	}

	@Test public void getConstantsPredicateFormula() {
	}

	@Test public void getTerms() {
	}

	@Test public void generateVariables() {
	}

	@Test public void termsToAttributes1() {
	}

	@Test public void termsToTyped() {
	}

	@Test public void termToTyped() {
	}

	@Test public void termsToAttributes2() {
	}

	@Test public void canonicalAttributes() {
	}

	@Test public void cast() {
	}

	@Test public void toStrings() {
	}

	@Test public void getTupleType() {
	}

	@Test public void meanDist() {
	}

	@Test public void retain() {
	}

	@Test public void connectedComponents() {
	}

	@Test public void deepCopy() {
	}

	@Test public void format1() {
	}

	@Test public void format2() {
	}
}
