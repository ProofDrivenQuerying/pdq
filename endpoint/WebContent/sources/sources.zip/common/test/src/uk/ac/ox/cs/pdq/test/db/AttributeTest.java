package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class AttributeTest  {

	@Test public void testAttributeTest2() {
	}
	@Test public void testAttributeTest1() {
	}

	@Test public void testGetType() {
	}

	@Test public void testGetName() {
	}

	@Test public void testEquals() {
	}

	@Test public void testHashCode() {
	}
}
