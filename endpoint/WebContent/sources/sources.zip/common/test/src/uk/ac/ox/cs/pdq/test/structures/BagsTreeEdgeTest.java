package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class BagsTreeEdgeTest {

	@Test public void BagsTreeEdge() {
	}

	@Test public void getSource() {
	}

	@Test public void getTarget() {
	}

	@Test public void getDependency() {
	}

	@Test public void testEquals() {
	}
}