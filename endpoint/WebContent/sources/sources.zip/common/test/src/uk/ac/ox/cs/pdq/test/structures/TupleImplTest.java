package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class TupleImplTest {

	@Test public void appendTuple() {}

	@Test public void getType() {}

	@Test public void size() {}

	@Test public void getValue() {}

	@Test public void getValues() {}

	@Test public void equals() {}
}
