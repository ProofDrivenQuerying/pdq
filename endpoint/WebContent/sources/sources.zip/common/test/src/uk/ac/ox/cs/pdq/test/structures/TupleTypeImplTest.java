package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class TupleTypeImplTest {

	@Test public void staticToClassArray() {}

	@Test public void size() {}

	@Test public void getType() {}

	@Test public void getTypes() {}

	@Test public void createTuple1() {}

	@Test public void createTuple2() {}

	@Test public void appendTuples() {}

	@Test public void append() {}

	@Test public void isAssignableFrom() {}

	@Test public void isInstance1() {}

	@Test public void isInstance2() {}

	@Test public void equals() {}
}