package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 *
 * @param <N>
 */

public class BagsTreeTest {

	@Test public void BagsTree1() {
	}

	@Test public void BagsTree2() {
	}

	@Test public void addVertex() {
	}

	@Test public void getBag() {
	}

	@Test public void getVertex() {
	}

	@Test public void getRoot() {
	}

	@Test public void getFacts() {
	}

	@Test public void replicate() {
	}
}
