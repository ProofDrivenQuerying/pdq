package uk.ac.ox.cs.pdq.test.db;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.google.common.base.Preconditions;

/**
 * A AccessMethod method
 * Stores the positions of a relation's attributes whose values are required to access the relation.
 *
 * @author Julien Leblay
 */
public class AccessMethodTest {

	/** Generated serial number */
	private static final long serialVersionUID = 1946416951995219490L;

	/** Types of access restrictions */
	public static enum AccessMethodTypes {
		FREE, LIMITED, BOOLEAN
	}

	public static final String DEFAULT_PREFIX = "mt_";

	private static int globalCounter = 0;

	/** Input attribute positions */
	private final List<Integer> inputs;

	/** Access restriction */
	private final AccessMethodTypes type;

	/** Name of the access restrictions */
	private final String name;

	/** String representation of the object */
	private String rep = null;

	/**
	 * Default constructor. Instantiates an inaccessible binding method
	 */
	public AccessMethodTest() {
		this(AccessMethodTypes.FREE, new ArrayList<Integer>());
	}

	/**
	 * Copy constructor.
	 */
	public AccessMethodTest(AccessMethodTest binding) {
		this(binding.name, binding.type, binding.getInputs());
	}


	/**
	 * @param type
	 * @param bindingPositions
	 */
	public AccessMethodTest(AccessMethodTypes type, List<Integer> bindingPositions) {
		this(DEFAULT_PREFIX + globalCounter++, type, bindingPositions);
	}

	/**
	 *
	 * @param name
	 * @param type
	 * @param bindingPositions
	 */
	public AccessMethodTest(String name, AccessMethodTypes type, List<Integer> bindingPositions) {
		Preconditions.checkArgument(type == AccessMethodTypes.FREE ? bindingPositions.isEmpty() : true);
		this.name = name;
		this.type = type;
		this.inputs = new ArrayList<>();
		if (bindingPositions != null) {
			for (Integer i : bindingPositions) {
				this.inputs.add(i);
			}
		}
	}

	/**
	 * @return the positions that are required inputs
	 */
	public List<Integer> getInputs() {
		return this.inputs;
	}

	/**
	 * @return the positions that are required inputs
	 */
	public List<Integer> getZeroBasedInputs() {
		List<Integer> zero = new ArrayList<>();
		for(Integer index:this.inputs) {
			zero.add(index-1);
		}
		return zero;
	}

	/**
	 * @return the type of the access restriction
	 */
	public AccessMethodTypes getType() {
		return this.type;
	}

	/**
	 * @return the binding's name.
	 */
	public String getName() {
		return this.name;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		return this.getClass().isInstance(o)
				&& this.name.equals(((AccessMethodTest) o).name)
				&& this.type.equals(((AccessMethodTest) o).type)
				&& this.inputs.equals(((AccessMethodTest) o).inputs);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.name, this.type, this.inputs);
	}

	@Override
	public String toString() {
		if (this.rep == null) {
			StringBuilder result = new StringBuilder();
			result.append(this.name).append(':');
			result.append(this.type);
			if (this.type.equals(AccessMethodTypes.LIMITED) == true) {
				char sep = '[';
				for (int i : this.inputs) {
					result.append(sep).append(i);
					sep = ',';
				}
				result.append(']');
			}
			this.rep = result.toString();
		}
		return this.rep;
	}
}
