package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class TripleTest {

	@Test public void getFirst() {}

	@Test public void getSecond() {}

	@Test public void getThird() {}

	@Test public void equals() {}
}
