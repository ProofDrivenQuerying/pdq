package uk.ac.ox.cs.pdq.test.fol;

import org.junit.Test;

public class FormulaEquivalence {

	@Test public void testApproximateEquivalence1() {
	}

	@Test public void testApproximateEquivalence2() {
	}

	@Test public void testApproximateEquivalence3() {
	}

	@Test public void testApproximateEquivalence4() {
	}

	@Test public void testApproximateEquivalence5() {
	}

	@Test public void testApproximateEquivalence6() {
	}
}
