package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public abstract class RelationTest {
	@Test public void RelationTest4() {
	}
	@Test public void RelationTest3() {
	}

	@Test public void RelationTest2() {
	}

	@Test public void RelationTest1() {
	}

	@Test public void getName() {
	}

	@Test public void getArity() {
	}

	@Test public void getAttributes() {
	}

	@Test public void getInputAttributes() {
	}

	@Test public void getAttribute() {
	}

	@Test public void getAttributeIndex() {
	}

	@Test public void getAttributeByName() {
	}

	@Test public void getAccessMethods() {
	}

	@Test public void addForeignKey() {
	}

	@Test public void addForeignKeys() {
	}

	@Test public void getForeignKey() {
	}

	@Test public void getForeignKeys() {
	}

	@Test public void getId() {
	}

	@Test public void addAccessMethod() {
	}

	@Test public void setAccessMethods() {
	}

	@Test public void setAccessMethods2() {
	}

	@Test public void getBinding() {
	}

	@Test public void createAtoms() {
	}

	@Test public void getVariables() {
	}

	@Test public void hasFreeAccess() {
	}

	@Test public void restEquals() {
	}

	@Test public void testHashCode() {
	}

	@Test public void getProperties() {
	}

	@Test public void getMetadata() {
	}

	@Test public void setMetadata() {
	}
}
