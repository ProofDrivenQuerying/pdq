package uk.ac.ox.cs.pdq.test.structures;

import org.junit.Test;

/**
 *
 * @author Julien Leblay
 */
public final class BooleanResultTest {

	@Test public void BooleanResult() {
	}

	@Test public void isEmpty() {
	}

	@Test public void size() {
	}

	@Test public void getValue() {
	}

	@Test public void howDifferent() {
	}

	@Test public void diff() {
	}
}
