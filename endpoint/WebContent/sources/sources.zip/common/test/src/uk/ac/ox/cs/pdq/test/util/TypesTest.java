package uk.ac.ox.cs.pdq.test.util;

import org.junit.Test;

public class TypesTest {

	@Test public void staticSimpleName() {
	}

	@Test public void staticCanonicalName() {
	}

	@Test public void staticEquals() {
	}

	@Test public void staticIsNumeric() {
	}

	@Test public void staticCast() {
	}
}
