package uk.ac.ox.cs.pdq.test.io;

import java.io.IOException;

import org.junit.Test;

public class ReadWriteTest {
	
	@Test
	public void testReadWriteSchema() throws IOException, ReflectiveOperationException {
//		SchemaGenerator gen = new SchemaGeneratorFirst(this.params);
//		Schema schema = gen.generate();
//		ConjunctiveQuery query = new QueryGeneratorFirst(schema, this.params).generate();
//		schema = new DependencyGeneratorFirst(schema, query, this.params).generate();
//		File f = new File("test/unit/schema-tmp.xml");
//		f.deleteOnExit();
//		try (
//				PrintStream ps = new PrintStream(f);
//				FileInputStream fis = new FileInputStream(f);) {
//			Writers.to(ps).in(XML).write(schema);
//			Schema readSchema = Readers.from(fis).read();
//			assertEquals("Read and written schemas differ", schema, readSchema); 
//		}
	}

	@Test
	public void testReadWriteQuery() throws ReflectiveOperationException, IOException {
//		SchemaGenerator gen = new SchemaGeneratorFirst(this.params);
//		Schema schema = gen.generate();
//		ConjunctiveQuery query = new QueryGeneratorFirst(schema, this.params).generate();
//		File f = new File("test/unit/query-tmp.xml");
//		f.deleteOnExit();
//		try (	PrintStream ps = new PrintStream(f);
//				FileInputStream fis = new FileInputStream(f);) {
//			Writers.to(ps).in(XML).write(query);
//			Query readQuery = Readers.with(schema).from(fis).read();
//			assertEquals("Read and written queries differ", query, readQuery); 
//		}
	}

	@Test
	public void testReadWritePlan() throws ReflectiveOperationException, IOException {
//		File f = new File("test/unit/plan-tmp.xml");
//		f.deleteOnExit();
//		try (	FileInputStream sis = new FileInputStream("test/unit/schema-mysql-tpch.xml");
//				FileInputStream pis = new FileInputStream("test/unit/plan.xml");
//				PrintStream ps = new PrintStream(f);
//				FileInputStream fis = new FileInputStream(f)) {
//
//			Schema schema = Readers.from(sis).read();
//			LinearPlan plan = Readers.with(schema).from(pis).read();
//			Writers.to(ps).in(XML).write(plan);
//			LinearPlan plan2 = Readers.with(schema).from(fis).read();
//			assertEquals("Read and written plans costs differ", plan.getCost(), plan2.getCost()); 
//			assertEquals("Read and written plans accesses differ", plan.getAccesses(), plan2.getAccesses()); 
//		}
	}

	@Test
	public void testReadWriteProof() throws ReflectiveOperationException, IOException {
//		File f = new File("test/unit/proof-tmp.xml");
//		f.deleteOnExit();
//		try (	FileInputStream sis = new FileInputStream("test/unit/schema.xml");
//				FileInputStream qis = new FileInputStream("test/unit/query.xml");
//				FileInputStream pis = new FileInputStream("test/unit/proof.xml");
//				PrintStream ps = new PrintStream(f);
//				FileInputStream fis = new FileInputStream(f)) {
//
//			Schema schema = Readers.from(sis).read();
//			Proof proof = Readers.with(schema).from(pis).read();
//			Writers.to(ps).in(XML).write(proof);
//			Proof proof2 = Readers.with(schema).from(fis).read();
//			assertEquals("Read and written proofs differ", proof, proof2); 
//		}
	}
}
