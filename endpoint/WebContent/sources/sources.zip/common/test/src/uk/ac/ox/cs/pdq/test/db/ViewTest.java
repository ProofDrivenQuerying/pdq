package uk.ac.ox.cs.pdq.test.db;

import org.junit.Test;

/**
 * @author Julien Leblay
 */
public class ViewTest  {

	@Test public void testViewTest3() {
	}

	@Test public void testViewTest2() {
	}

	@Test public void testGetId() {
	}

	@Test public void testGetDependency() {
	}

	@Test public void testSetDependency() {
	}

	@Test public void equals() {
	}
}
