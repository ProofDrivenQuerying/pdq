package uk.ac.ox.cs.pdq.test.fol;


public class UtilityTest {

	//	@Test public void testAccessibleLength(Collection<AtomicFormula>) {
	//
	//	}
	//
	//	@Test public void testAccessibleOnly(Collection<AtomicFormula>) {
	//
	//	}
	//
	//	@Test public void testContainsNoPredicateNames(Collection<AtomicFormula>, Collection<String>) {
	//
	//	}
	//
	//	@Test public void testContainsPredicates(Collection<AtomicFormula>, AtomicFormula) {
	//
	//	}
	//
	//	@Test public void testContainsPredicates(Collection<AtomicFormula>, Collection<AtomicFormula>) {
	//
	//	}
	//
	//	@Test public void testCreateChaseTable(Signature) {
	//
	//	}
	//
	//	@Test public void testCreateTable(String, List<Attribute<?>>) {
	//
	//	}
	//
	//	@Test public void testCreateTable(View) {
	//
	//	}
	//
	//	@Test public void testGenerateVariableTerms(Relation) {
	//
	//	}
	//
	//	@Test public void testGetVariables(Collection<AtomicFormula>) {
	//
	//	}
	//
	//	@Test public void testGetVariableTerms(Collection<AtomicFormula>) {
	//
	//	}
	//
	//	@Test public void testGround(List<AtomicFormula>, Map<Term, Term>) {
	//
	//	}
	//
	//	@Test public void testRemoveDuplicates(List<T>) {
	//
	//	}
	//
	//	@Test public void testSearch(Collection<T>, T) {
	//
	//	}
	//
	//	@Test public void testSearchAtomByName(Collection<AtomicFormula>, String) {
	//
	//	}
	//
	//	@Test public void testSearchBagById(Set<Bag>, int) {
	//
	//	}
	//
	//	@Test public void testVarIdsToTerms(Collection<VariableId>) {
	//
	//	}
}
