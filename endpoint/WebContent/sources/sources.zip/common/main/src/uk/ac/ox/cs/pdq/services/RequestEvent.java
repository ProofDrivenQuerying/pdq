package uk.ac.ox.cs.pdq.services;

import uk.ac.ox.cs.pdq.services.AccessEvent;
import uk.ac.ox.cs.pdq.services.ResponseEvent;


/**
 * An access's request event
 * @author Julien Leblay
 *
 */
public interface RequestEvent extends AccessEvent {
	
	/**
	 * @return ResponseEvent
	 */
	ResponseEvent processRequest();
}
