package uk.ac.ox.cs.pdq.algebra.predicates;

import java.util.Collection;
import java.util.Iterator;

import uk.ac.ox.cs.pdq.util.Tuple;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;

/**
 * Evaluates a Collection of predicates conjunctively, i.e. all the underlying
 * predicates must be satisfied for this predicate to be satisfied.
 *
 * @author Julien Leblay
 */
public class ConjunctivePredicate<T extends Predicate> implements Predicate, Iterable<T> {

	/** The value to which the tuple must be equals at the given position */
	private final Collection<T> predicates;

	/**
	 * Default constructor
	 */
	public ConjunctivePredicate() {
		this(Lists.<T>newArrayList());
	}

	/**
	 * Default constructor
	 * @param predicate T
	 */
	public ConjunctivePredicate(T predicate) {
		this(Lists.newArrayList(predicate));
	}

	/**
	 * Default constructor
	 * @param predicates
	 */
	public ConjunctivePredicate(Collection<T> predicates) {
		this.predicates = predicates;
	}

	/**
	 * @return the number of predicates in the conjunction
	 */
	public int size() {
		return this.predicates.size();
	}

	/**
	 * @return true if the predicate is empty
	 */
	public boolean isEmpty() {
		return this.predicates.size() == 0;
	}

	/**
	 * Adds the given predicate to the conjunction
	 * @param p
	 */
	public void addPredicate(T p) {
		this.predicates.add(p);
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.predicates.Predicate#isSatisfied(uk.ac.ox.cs.pdq.tuple.Tuple)
	 */
	@Override
	public boolean isSatisfied(Tuple t) {
		for (Predicate p: this.predicates) {
			if (!p.isSatisfied(t)) {
				return false;
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<T> iterator() {
		return this.predicates.iterator();
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		String sep = "(";
		if (!this.predicates.isEmpty()) {
			for (Predicate p: this) {
				result.append(sep).append(p);
				sep = "&";
			}
			result.append(')');
		}
		return result.toString();
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.predicates.equals(((ConjunctivePredicate) o).predicates);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hashCode(this.predicates);
	}
}
