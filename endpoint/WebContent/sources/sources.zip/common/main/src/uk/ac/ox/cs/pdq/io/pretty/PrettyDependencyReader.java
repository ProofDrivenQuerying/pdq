package uk.ac.ox.cs.pdq.io.pretty;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.IOUtils;

import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.db.Schema;
import uk.ac.ox.cs.pdq.db.TGD;
import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.db.builder.DependencyBuilder;
import uk.ac.ox.cs.pdq.fol.Conjunction;
import uk.ac.ox.cs.pdq.fol.LogicalSymbols;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.fol.Variable;
import uk.ac.ox.cs.pdq.io.Reader;
import uk.ac.ox.cs.pdq.io.ReaderException;
import uk.ac.ox.cs.pdq.util.Types;

import com.google.common.base.Preconditions;

/**
 * A pretty reader for dependencies.
 * @author Julien Leblay
 */
public class PrettyDependencyReader implements Reader<TGD> {

	/** The dependency being built. */
	private DependencyBuilder builder = null;
	
	/** The schema the dependency is based on . */
	private final Schema schema;

	/**
	 * Constructor for PrettyDependencyReader.
	 * @param schema Schema
	 */
	public PrettyDependencyReader(Schema schema) {
		this.schema = schema;
	}
	
	/**
	 * @param in InputStream
	 * @return TGD
	 * @see uk.ac.ox.cs.pdq.io.Reader#read(InputStream)
	 */
	@Override
	public TGD read(InputStream in) {
		this.builder = new DependencyBuilder();
		try {
			StringWriter writer = new StringWriter();
			IOUtils.copy(in, writer, "UTF-8");
			String s = writer.toString();
			return this.parse(s); 
		} catch (IOException e) {
			throw new ReaderException("Could read input stream");
		}
	}

	/**
	 * @param s String
	 * @return TGD
	 */
	private TGD parse(String s) {
		Preconditions.checkArgument(s != null);
		String[] sides = s.split(LogicalSymbols.IMPLIES.toString());
		if (sides.length != 2) {
			throw new ReaderException("Dependency must have exactly one head and one body");
		}
		for (PredicateFormula p: this.parseConjunction(sides[0])) {
			this.builder.addLeftAtom(p);
		}
		for (PredicateFormula p: this.parseConjunction(sides[1])) {
			this.builder.addRightAtom(p);
		}
		return this.builder.build();
	}
	
	/**
	 * @param s String
	 * @return Conjunction<PredicateFormula>
	 */
	public Conjunction<PredicateFormula> parseConjunction(String s) {
		String[] sAtoms = s.split(LogicalSymbols.AND.toString());
		if (sAtoms == null || sAtoms.length == 0) {
			throw new ReaderException("Atom list cannot be empty.");
		}
		Collection<PredicateFormula> atoms = new LinkedList<>();
		for (String atom: sAtoms) {
			String trimmed = atom.trim();
			int openIndex = trimmed.indexOf('(');
			int closeIndex = trimmed.indexOf(')');
			if (openIndex < 0 || closeIndex < 0 || closeIndex <= openIndex) {
				throw new ReaderException("Each atom must consistent opening and closing parenthesis.");
			}
			if (trimmed.length() > closeIndex + 1) {
				throw new ReaderException("Atom can only be followed by a logical operator.");
			}
			String prefix = trimmed.substring(0, openIndex);
			Relation relation = this.schema.getRelation(prefix);
			if (relation == null) {
				throw new ReaderException("Relation " + prefix + " is not part of the schema.");
			}
			String[] sTerms = trimmed.substring(openIndex + 1, closeIndex).split(",");
			if (sTerms.length != relation.getArity()) {
				throw new ReaderException("Relation " + prefix + " must have exactly " + relation.getArity() + " arguments.");
			}
			List<Term> terms = new ArrayList<>();
			for (int i = 0, l = sTerms.length; i < l; i++) {
				String t = sTerms[i].trim();
				if (t.startsWith("'")) {
					if (t.endsWith("'")) {
						try {
							Object o  = Types.cast(relation.getAttribute(i).getType(), t.substring(1, t.length() - 1));
							terms.add(new TypedConstant<>(o));
						} catch (ClassCastException e) {
							throw new ReaderException(e.getMessage());
						}
					} else {
						throw new ReaderException("Constant declaration not properly closed " + t);
					}
				} else if (t.endsWith("'")) {
					throw new ReaderException("Constant declaration not properly opened " + t);
				} else {
					terms.add(new Variable(t));
				}
			}
			atoms.add(new PredicateFormula(relation, terms));
		}
		return Conjunction.of(atoms);
	}
	
//	/**
//	 * @param args String[]
//	 */
//	public static void main(String... args) {
//		System.setProperty("user.dir", "/auto/users/leblay/.pdq/");
//		try(InputStream sin = new FileInputStream("/auto/users/leblay/.pdq/schemas/5.s")) {
//			Schema s = Readers.from(sin).read();
//			Reader<TGD> reader = new PrettyDependencyReader(s);
//			Writer<TGD> writer = PrettyFormulaWriter.to(System.out);
//			writer.write(System.out, reader.read(new ByteArrayInputStream("YahooPlaces(woeid, countryName, type, 'Country', _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27) -> YahooCountries(woeid, type, 'Country', countryName)".getBytes())));
//			System.out.println("\n-----------------------------");
//			writer.write(System.out, reader.read(new ByteArrayInputStream("City(cityId, cityName, countryCode, _36, _37, _38, _39) & Country(countryId, countryCode, countryName, continentName, capital, _40, _41, _42, _43, _44, _45) -> YahooPlaces(cityId, cityName, type, 'Town', _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59) & YahooCountries(countryId, type, 'Country', countryName) 	& YahooBelongsTo(cityId, countryId, _60, _61, _62)".getBytes())));
//			System.out.println("\n-----------------------------");
//			writer.write(System.out, reader.read(new ByteArrayInputStream("YahooContinents(continentId, type, 'Continent', continentName) & YahooCountries(countryId, type, 'Country', countryName) & YahooBelongsTo(countryId, continentId, _203, _204, _205) 	-> Continent(continentId, continentName, _206, _207, _208, _209, _210) & Country(countryId, countryCode, countryName, continentName, _211, _212, _213, _214, _215, _216, _217)".getBytes())));
//			System.out.println("\n-----------------------------");
//			writer.write(System.out, reader.read(new ByteArrayInputStream("WBCountries(wbid, countryCode, countryName, incomeLevel, lendingType, capital, latitude, longitude) -> Country(countryId, countryCode, countryName, continentName, _218, _219, _220, _221, _222, _223, _224)	& CapitalCity(cityId, capital, countryCode, _225, _226, _227, _228)".getBytes())));
//			System.out.println("\n-----------------------------");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
}
