package uk.ac.ox.cs.pdq.fol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;

/**
 * A disjunction
 * @author Julien Leblay
 *
 * @param <T>
 */
public final class Disjunction<T extends Formula> extends NaryFormula<T> {

	/**
	 * Constructor for Disjunction.
	 * @param subFormulas Collection<T>
	 */
	private Disjunction(Collection<T> subFormulas) {
		super(LogicalSymbols.OR, subFormulas);
	}

	/**
	 * Constructor for Disjunction.
	 * @param subFormulas T[]
	 */
	private Disjunction(T... subFormulas) {
		super(LogicalSymbols.OR, Lists.newArrayList(subFormulas));
	}

	/**
	 * @param subFormulas T[]
	 * @return Disjunction<T>
	 */
	public static <T extends Formula> Disjunction<T> of(T... subFormulas) {
		return new Disjunction<>(subFormulas);
	}

	/**
	 * @param subFormulas Collection<T>
	 * @return Disjunction<T>
	 */
	public static <T extends Formula> Disjunction<T> of(Collection<T> subFormulas) {
		return new Disjunction<>(subFormulas);
	}

	/**
	 * @param mapping Map<Variable,Term>
	 * @return Formula
	 * @see uk.ac.ox.cs.pdq.formula.Formula#ground(Map<Variable,Term>)
	 */
	@Override
	public Formula ground(Map<Variable, Constant> mapping) {
		List<T> result = new ArrayList<>(this.subFormulas.size());
		for (T p: this.subFormulas) {
			result.add((T) p.ground(mapping));
		}
		return Disjunction.of(result);
	}

	/**
	 * @return a generic formula builder.
	 */
	public static Builder builder() {
		return new Builder();
	}

	/**
	 * A simple builder for disjunctions.
	 *
	 * @author Julien Leblay
	 */
	public static class Builder implements uk.ac.ox.cs.pdq.builder.Builder<Disjunction<?>> {

		private LinkedList<Formula> current = new LinkedList<>();

		/**
		 * @param disjuncts Formula[]
		 * @return Builder
		 */
		public Builder or(Formula... disjuncts) {
			return this.or(Lists.newArrayList(disjuncts));
		}

		/**
		 * @param disjuncts List<Formula>
		 * @return Builder
		 */
		public Builder or(List<Formula> disjuncts) {
			for (Formula f: disjuncts) {
				this.current.add(f);
			}
			return this;
		}

		/**
		 * @return Disjunction<?>
		 * @see uk.ac.ox.cs.pdq.builder.Builder#build()
		 */
		@Override
		public Disjunction<?> build() {
			assert this.current != null;
			return Disjunction.of(this.current);
		}
	}
}
