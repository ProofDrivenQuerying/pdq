package uk.ac.ox.cs.pdq.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.jgrapht.DirectedGraph;
import org.jgrapht.alg.ConnectivityInspector;
import org.jgrapht.alg.CycleDetector;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;

import uk.ac.ox.cs.pdq.db.builder.SchemaBuilder;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Query;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

/**
 *
 * A relational schema
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 */
public class Schema {

	/** Relations */
	private final Map<String, Relation> relIndex;
	protected final List<Relation> relations;

	/** Distribution of relations by arity */
	private final List<Relation>[] arityDistribution;

	/** Tuple generating dependencies */
	private final Map<Integer, Constraint> dependencyIndex;

	protected final List<Constraint> schemaDependencies;

	/** True if the schema contains at least one view */
	private final boolean containsViews;

	/** True if the schema contains cycles*/
	protected Boolean isCyclic = null;

	/** Constants that appear to the schema dependencies*/
	protected Collection<TypedConstant<?>> dependencyConstants = null;

	/** A map of the string representation of a constant to the constant*/
	protected Map<String, TypedConstant<?>> constantsMap = new LinkedHashMap<>();

	protected List<Constraint> views = new ArrayList<>();
	protected List<Constraint> inverseViews = new ArrayList<>();

	public Schema() {
		this(new ArrayList<Relation>(), new ArrayList<Constraint>());
	}

	/**
	 * Constructor for Schema.
	 * @param relations Collection<Relation>
	 */
	public Schema(Collection<Relation> relations) {
		this(relations, new ArrayList<Constraint>());
	}

	/**
	 * Schema constructor
	 * @param relations
	 * 		The input relations
	 * @param dependencies
	 * 		The input dependencies
	 */
	public Schema(Collection<Relation> relations, Collection<Constraint> dependencies) {
		int maxArity = 0;
		boolean containsViews = false;
		Map<String, Relation> rm = new LinkedHashMap<>();
		for (Relation relation : relations) {
			rm.put(relation.getName(), relation);
			if (maxArity < relation.getArity()) {
				maxArity = relation.getArity();
			}
			containsViews |= relation instanceof View;
			if(relation instanceof View) {
				this.views.add(((View) relation).getDependency());
			}
		}
		this.containsViews = containsViews;

		this.arityDistribution = new List[maxArity + 1];
		for (int i = 0, l = this.arityDistribution.length; i < l; i++) {
			this.arityDistribution[i] = new ArrayList<>();
		}
		for (Relation r:relations) {
			this.arityDistribution[r.getArity()].add(r);
		}

		Map<Integer, Constraint> dm = new LinkedHashMap<>();
		for (Constraint ic:dependencies) {
			if (ic instanceof TGD) {
				dm.put(((TGD) ic).getId(), ic);
			}
		}

		this.relIndex = ImmutableMap.copyOf(rm);
		this.dependencyIndex = ImmutableMap.copyOf(dm);
		this.relations = ImmutableList.copyOf(this.relIndex.values());
		this.schemaDependencies = ImmutableList.copyOf(this.dependencyIndex.values());
		this.createConstantsMap();
	}

	/**
	 * @return List<IC>
	 */
	public List<Constraint> getViews() {
		return this.views;
	}

	/**
	 * @return boolean
	 */
	public boolean containsViews() {
		return this.containsViews;
	}

	/**
	 * @param i int
	 * @return List<Relation>
	 */
	public List<Relation> getRelationsByArity(int i) {
		return this.arityDistribution[i];
	}

	/**
	 * @return List<Relation>
	 */
	public List<Relation> getRelations() {
		return this.relations;
	}

	/**
	 * @return Map<String,Relation>
	 */
	public Map<String, Relation> getRelationsMap() {
		return this.relIndex;
	}

	/**
	 * @return int
	 */
	public int getMaxArity() {
		return this.arityDistribution.length;
	}

	/**
	 * @return List<IC>
	 */
	public List<Constraint> getDependencies() {
		return this.schemaDependencies;
	}

	/**
	 * @param relationName String
	 * @return Relation
	 */
	public Relation getRelation(String relationName) {
		return this.relIndex.get(relationName);
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append('{');
		if (!this.relations.isEmpty()) {
			result.append("\n\t{");
			for (Relation r : this.relations) {
				result.append("\n\t\t").append(r);
			}
			result.append("\n\t}");
		}
		if (!this.schemaDependencies.isEmpty()) {
			result.append("\n\t{");
			for (Constraint ic : this.schemaDependencies) {
				result.append("\n\t\t").append(ic);
			}
			result.append("\n\t}");
		}
		result.append("\n}");
		return result.toString();
	}

	/**
	 * @return true if the schema contains cycles
	 */
	public boolean isCyclic() {
		if (this.isCyclic == null) {
			DirectedGraph<PredicateFormula, DefaultEdge> simpleDepedencyGraph = new DefaultDirectedGraph<>(DefaultEdge.class);
			for (Relation relation:this.relations) {
				simpleDepedencyGraph.addVertex(relation.createAtoms());
			}
			for (Constraint ic:this.schemaDependencies) {
				List<PredicateFormula> leftAtoms = ic.getLeft().getPredicates();
				List<PredicateFormula> rightAtoms = ic.getRight().getPredicates();
				for (PredicateFormula left : leftAtoms) {
					for (PredicateFormula right : rightAtoms) {
						PredicateFormula leftVertex = this.searchDependencyGraph(simpleDepedencyGraph, left);
						PredicateFormula rightVertex = this.searchDependencyGraph(simpleDepedencyGraph, right);
						simpleDepedencyGraph.addEdge(leftVertex, rightVertex);
					}
				}
			}
			CycleDetector<PredicateFormula, DefaultEdge> cycleDetector = new CycleDetector<>(simpleDepedencyGraph);
			this.isCyclic = cycleDetector.detectCycles();
		}
		return this.isCyclic;
	}

	/**
	 * @param simpleDepedencyGraph A schema dependency graph
	 * @param atom An input atom
	 * @return the atom which has the same predicate with the input one
	 */
	private PredicateFormula searchDependencyGraph(
			DirectedGraph<PredicateFormula, DefaultEdge> simpleDepedencyGraph,
			PredicateFormula atom) {
		for (PredicateFormula vertex: simpleDepedencyGraph.vertexSet()) {
			if (atom.getPredicateName().equals(vertex.getPredicateName())) {
				return vertex;
			}
		}
		return null;
	}

	/**
	 * @return the constants appearing in the schema dependencies
	 */
	public Collection<TypedConstant<?>> getDependencyConstants() {
		if (this.dependencyConstants == null) {
			this.dependencyConstants = new LinkedHashSet<>();
			for (Constraint ic : this.schemaDependencies) {
				this.dependencyConstants.addAll(ic.getSchemaConstants());
			}
		}
		return this.dependencyConstants;
	}

	/**
	 * Creates a map of the constants that appear in the schema dependencies.
	 */
	private void createConstantsMap() {
		for (TypedConstant<?> constant: this.getDependencyConstants()) {
			this.constantsMap.put(constant.toString(), constant);
		}
	}

	/**
	 * Updates the map of dependency constants
	 * @param constants Collection<TypedConstant<?>>
	 */
	public void updateConstantsMap(Collection<TypedConstant<?>> constants) {
		for (TypedConstant<?> constant: constants) {
			this.constantsMap.put(constant.toString(), constant);
		}
	}

	/**
	 * @return Map<String,TypedConstant<?>>
	 */
	public Map<String, TypedConstant<?>> getConstantsMap() {
		return this.constantsMap;
	}

	/**
	 * @param constant String
	 * @return TypedConstant<?>
	 */
	public TypedConstant<?> getConstant(String constant) {
		return this.constantsMap.get(constant);
	}

	/**
	 * @param relation
	 * @return true if the given relation is part of the schema.
	 */
	public boolean contains(Relation relation) {
		Preconditions.checkArgument(relation != null);
		return contains(relation.getName());
	}

	/**
	 * @param relation
	 * @return true if the given relation is part of the schema.
	 */
	public boolean contains(String relationName) {
		return this.relIndex.containsKey(relationName);
	}

	/**
	 * @param dependency
	 * @return true if the given dependency is part of the schema
	 */
	public boolean contains(Constraint dependency) {
		if (this.schemaDependencies.contains(dependency)) {
			return true;
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.relations.equals(((Schema) o).relations)
				&& this.schemaDependencies.equals(((Schema) o).schemaDependencies);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.relations, this.schemaDependencies);
	}

	/**
	 * @return a new schema builder
	 */
	public static SchemaBuilder builder() {
		return new SchemaBuilder();
	}

	/**
	 * @param schema
	 * @return a new schema builder containing all the relations and
	 *         dependencies already in the given schema
	 */
	public static SchemaBuilder builder(Schema schema) {
		return new SchemaBuilder(schema);
	}

	/**
	 * @param query
	 * @return The relations that are reachable, w.r.t. the input query after creating the schema dependency graph
	 */
	public List<Relation> getReachableRelations(Query<?> query) {

		List<Relation> reachableRelations = new ArrayList<>();
		DirectedGraph<PredicateFormula, DefaultEdge> simpleDepedencyGraph = new DefaultDirectedGraph<>(DefaultEdge.class);
		// The vertices of the schema dependency graph are the schema relations (casted to atoms)
		for (Relation relation: this.relations) {
			simpleDepedencyGraph.addVertex(relation.createAtoms());
		}

		/*
		 * For each IC, get its left- and its right- hand sides.
		 * For each atom in its left-hand side create an edge to every atom is each right-hand side
		 */
		for (Constraint ic: this.schemaDependencies) {
			List<PredicateFormula> leftAtoms = ic.getLeft().getPredicates();
			List<PredicateFormula> rightAtoms = ic.getRight().getPredicates();
			for (PredicateFormula left:leftAtoms) {
				for (PredicateFormula right:rightAtoms) {
					PredicateFormula leftVertex = this.searchDependencyGraph(simpleDepedencyGraph, left);
					PredicateFormula rightVertex = this.searchDependencyGraph(simpleDepedencyGraph, right);
					simpleDepedencyGraph.addEdge(leftVertex, rightVertex);
				}
			}
		}

		// For each query conjunct find the vertices of the graph with the same predicate
		Collection<PredicateFormula> queryAtoms = query.getBody().getPredicates();
		List<PredicateFormula> queryVertices = new ArrayList<>();
		for (PredicateFormula atom: queryAtoms) {
			PredicateFormula queryVertex = this.searchDependencyGraph(simpleDepedencyGraph, atom);
			queryVertices.add(queryVertex);
		}

		// Perform path checks in the dependency graph
		ConnectivityInspector<PredicateFormula, DefaultEdge> connectivity = new ConnectivityInspector<>(simpleDepedencyGraph);

		/*
		 * For each vertex of the graph, if there exists an undirected path
		 * between it and one of the query's conjuncts, then keep this vertex;
		 * otherwise, remove it from the dependency graph
		 */
		for (PredicateFormula source:simpleDepedencyGraph.vertexSet()) {
			Iterator<PredicateFormula> iterator = queryVertices.iterator();
			boolean hasPath = false;
			while (iterator.hasNext() && !hasPath) {
				PredicateFormula destination = iterator.next();
				if (connectivity.pathExists(source, destination)) {
					hasPath = true;
				}
			}
			if (hasPath) {
				reachableRelations.add((Relation) source.getSignature());
			}
		}
		return reachableRelations;
	}
}
