package uk.ac.ox.cs.pdq.db;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import uk.ac.ox.cs.pdq.fol.Constant;
import uk.ac.ox.cs.pdq.fol.Evaluatable;
import uk.ac.ox.cs.pdq.fol.Formula;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;
import uk.ac.ox.cs.pdq.fol.Rule;
import uk.ac.ox.cs.pdq.fol.Signature;
import uk.ac.ox.cs.pdq.fol.Variable;

/**
 * A schema constraint
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 */
public interface Constraint<L extends Formula, R extends Formula>
extends Evaluatable, Rule<L, R> {

	/**
	 * @param match
	 * 		Input mapping from variables to variables/constants
	 * @param canonicalNames
	 * 		True if we assign Skolem constants to the existentially quantified variables
	 * @return the grounded dependency using the input mapping
	 */
	Constraint<L, R> fire(Map<Variable, Constant> match, boolean canonicalNames);

	/**
	 * @return the schema constants of the dependency
	 */
	Collection<TypedConstant<?>> getSchemaConstants();

	/**
	 * @return the view that corresponds to this dependency.
	 * 		If this dependency does not come from a view then null is returned
	 */
	View definesView();

	/**
	 * @return the left-hand side of the dependency
	 */
	L getLeft();

	/**
	 * @return the right-hand side of the dependency
	 */
	R getRight();


	/**
	 * @return List<PredicateFormula>
	 */
	List<PredicateFormula> getPredicates();

	/**
	 * @return the variables of both sides of the dependency
	 */
	Set<Variable> getBothSideVariables();

	/**
	 * @return true if the dependency contains the given relation signature in
	 * the left or right hand side.
	 */
	@Override
	boolean contains(Signature s);
}
