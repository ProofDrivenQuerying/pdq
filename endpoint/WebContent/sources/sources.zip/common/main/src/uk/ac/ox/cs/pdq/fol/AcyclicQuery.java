package uk.ac.ox.cs.pdq.fol;

import java.util.ArrayList;
import java.util.List;


/**
 * An acyclic query
 *
 * @author Efthymia Tsamoura
 */
public class AcyclicQuery extends ConjunctiveQuery {

	/**
	 * @param name The query's name
	 * @param head The query's head terms
	 * @param right The query's body
	 */
	public AcyclicQuery(String name, List<Term> head, Conjunction<PredicateFormula> right) {
		super(name, head, right);
	}

	/**
	 * @param left The query's head
	 * @param right The query's body
	 */
	public AcyclicQuery(PredicateFormula left, Conjunction<PredicateFormula> right) {
		super(left, right);
	}

	/**
	 * @return the suffix queries
	 */
	public List<AcyclicQuery> getSuffixQueries() {
		List<AcyclicQuery> ret = new ArrayList<>();
		List<PredicateFormula> atoms = new ArrayList<>(this.body.getSubFormulas());
		for (int i = atoms.size() - 2; i >= 0; --i) {
			List<PredicateFormula> subset = atoms.subList(i, atoms.size());
			List<Variable> f = subset.get(0).getVariables();
			AcyclicQuery cq = new AcyclicQuery(
					new PredicateFormula(new Signature("Q", f.size()), f),
					Conjunction.of(subset));
			ret.add(cq);
		}
		return ret;
	}

	/**
	 * @return the last suffix query
	 */
	public AcyclicQuery getLastQuery() {
		List<PredicateFormula> atoms = new ArrayList<>(this.body.getSubFormulas());
		PredicateFormula atom = atoms.get(atoms.size() - 1);
		AcyclicQuery cq = new AcyclicQuery(
				new PredicateFormula(new Signature("Q", 0),
						new ArrayList<Term>()),
						Conjunction.of(atom));
		return cq;
	}
}
