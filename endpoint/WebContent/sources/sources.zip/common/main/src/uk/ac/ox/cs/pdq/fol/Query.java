package uk.ac.ox.cs.pdq.fol;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import uk.ac.ox.cs.pdq.db.TypedConstant;

/**
 * Query interface
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 */
public interface Query<S extends Formula> extends Formula, Evaluatable, Rule<S, PredicateFormula> {

	/**
	 * @return true if the query is boolean
	 */
	boolean isBoolean();

	/**
	 * @return any sub-query of the query for any combination of free/existential variables
	 */
	List<Query<S>> getImportantSubqueries();

	/**
	 *
	 * @return the query's body * @see uk.ac.ox.cs.pdq.formula.Evaluatable#getBody()
	 */
	@Override
	S getBody();

	/**
	 * @return the query's head * @see uk.ac.ox.cs.pdq.formula.Rule#getHead()
	 */
	@Override
	PredicateFormula getHead();

	/**
	 * @return the constants that appear in the query's body
	 */
	Collection<TypedConstant<?>> getSchemaConstants();
	

	/**
	 * @return a map of query's free variables to chase constants.
	 */
	Map<Variable, Constant> getFreeToCanonical();
	
	/**
	 * @return a map of query's variables to chase constants appear in the canonical query
	 */
	Map<Variable, Constant> canonicalMapping();

	/**
	 *
	 * @param mapping Map<Variable,Term>
	 * @return a copy of the query grounded using the given mapping
	 * @see uk.ac.ox.cs.pdq.formula.Formula#ground(Map<Variable,Term>)
	 */
	@Override
	Formula ground(Map<Variable, Constant> mapping);

	/**
	 *
	 * @return the canonical query
	 */
	S getCanonicalQuery();
}
