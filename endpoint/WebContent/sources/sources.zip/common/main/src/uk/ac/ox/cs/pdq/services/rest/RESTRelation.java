package uk.ac.ox.cs.pdq.services.rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import uk.ac.ox.cs.pdq.db.AccessMethod;
import uk.ac.ox.cs.pdq.db.Attribute;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.db.wrappers.RelationAccessWrapper;
import uk.ac.ox.cs.pdq.AccessException;
import uk.ac.ox.cs.pdq.services.rest.InputMethod;
import uk.ac.ox.cs.pdq.services.rest.OutputMethod;
import uk.ac.ox.cs.pdq.services.rest.RESTAccess;
import uk.ac.ox.cs.pdq.services.rest.RESTAttribute;
import uk.ac.ox.cs.pdq.services.rest.RESTRelation;
import uk.ac.ox.cs.pdq.services.rest.RESTRequestEvent;
import uk.ac.ox.cs.pdq.services.rest.RESTResponseEvent;
import uk.ac.ox.cs.pdq.services.rest.StaticInput;
import uk.ac.ox.cs.pdq.services.Service;
import uk.ac.ox.cs.pdq.services.policies.UsagePolicy;
import uk.ac.ox.cs.pdq.services.policies.UsagePolicyViolationException;
import uk.ac.ox.cs.pdq.services.policies.UsageViolationExceptionHandler;
import uk.ac.ox.cs.pdq.util.Pipelineable;
import uk.ac.ox.cs.pdq.util.ResetableIterator;
import uk.ac.ox.cs.pdq.util.Table;
import uk.ac.ox.cs.pdq.util.Tuple;
import uk.ac.ox.cs.pdq.util.TupleType;
import uk.ac.ox.cs.pdq.util.Types;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.eventbus.EventBus;

/**
 * Wrapper class for RESTful accessible relations.
 * 
 * @author Julien Leblay
 *
 */
public final class RESTRelation extends Relation implements Service, Pipelineable, RelationAccessWrapper {

	/**  */
	private static final long serialVersionUID = -5829653747851001121L;

	/** Logger. */
	private static Logger log = Logger.getLogger(RESTRelation.class);

	/**
	 * All list of attributes the including the relations actual attributes,
	 * plus additional, possibly interleaved static attributes.
	 */
	private final List<RESTAttribute> allAttributes;

	/** Event bus where pre- and post-process event are propagated. */
	private final EventBus eventBus = new EventBus(new UsageViolationExceptionHandler());
	
	/** The service's base URL */
	private final String url;

	/** The service's result delimiter */
	private final String resultDelimiter;

	/** Response cache */
	Map<Collection<Tuple>, List<Tuple>> cache = new LinkedHashMap<>();

	/** Completed inputs */
	Set<Collection<Tuple>> completed = new LinkedHashSet<>();

	/**
	 * Default constructor.
	 * @param name
	 * @param attributes
	 * @param accessMethods
	 * @param allAttributes
	 * @param policies
	 * @param url String
	 * @param resultDelim String
	 */
	public RESTRelation(
			String name, List<RESTAttribute> attributes,
			List<AccessMethod> accessMethods,
			List<RESTAttribute> allAttributes, 
			String url, String resultDelim,
			Collection<UsagePolicy> policies) {
		super(name, attributes, accessMethods);
		Preconditions.checkArgument(url != null);
		Preconditions.checkArgument(policies != null);

		this.allAttributes = allAttributes;
		this.url = url;
		this.resultDelimiter = resultDelim != null ? resultDelim : "";
		for (UsagePolicy policy: policies) {
			this.register(policy);
		}
	}

	/**
	 * @param inputAttributes List<? extends Attribute>
	 * @param inputs ResetableIterator<Tuple>
	 * @return ResetableIterator<Tuple>
	 * @see uk.ac.ox.cs.pdq.wrappers.Pipelineable#iterator(List<? extends Attribute>, ResetableIterator<Tuple>)
	 */
	@Override
	public ResetableIterator<Tuple> iterator(List<? extends Attribute> inputAttributes, ResetableIterator<Tuple> inputs) {
		return new AccessIterator((List<RESTAttribute>) inputAttributes, inputs); 
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.Pipelineable#iterator()
	 */
	@Override
	public ResetableIterator<Tuple> iterator() {
		return new AccessIterator(); 
	}
	
	/**
	 * @param inputHeader
	 * @param inputTuples
	 * @return Table
	 * @see uk.ac.ox.cs.pdq.services.Service#access(Table)
	 */
	@Override
	public Table access(List<? extends Attribute> inputHeader,
			ResetableIterator<Tuple> inputTuples) {
		List<RESTAttribute> inputAttributes = new LinkedList<>();
		for (Attribute a: inputHeader) {
			inputAttributes.add((RESTAttribute) this.getAttribute(a.getName()));
		}
		ResetableIterator<Tuple> iterator = this.iterator(inputAttributes, inputTuples);
		iterator.open();
		Table result = new Table(this.getAttributes());
		while (iterator.hasNext()) {
			result.appendRow(iterator.next());
		}
		return result;
	}
	
	/**
	 * @return Table
	 * @see uk.ac.ox.cs.pdq.services.Service#access(Table)
	 */
	@Override
	public Table access() {
		ResetableIterator<Tuple> iterator = this.iterator();
		iterator.open();
		Table result = new Table(this.getAttributes());
		while (iterator.hasNext()) {
			result.appendRow(iterator.next());
		}
		return result;
	}
	/**
	 * @param inputs
	 * @return the set of input methods appearing in the given REST attributes 
	 * list.
	 */
	private Set<InputMethod> getInputMethod(List<RESTAttribute> inputs) {
		Set<InputMethod> result = new LinkedHashSet<>();
		for (RESTAttribute a: this.allAttributes) {
			if (a instanceof StaticInput || inputs.contains(a)) {
				InputMethod m = a.getInputMethod();
				if (m != null) {
					result.add(m);
				}
			}
		}
		return result;
	}

	/**
	 * @param inputs
	 * @param tuples Table
	 * @return a map containing input parameter to be use to build a service 
	 * request. The parameters include static parameters and access-specific
	 * parameters. The key of the map correspond to either input method names,
	 * template entries or the input attribute names themselves.
	 */
	private Map<String, Object> getInputParams(List<RESTAttribute> inputs, Table tuples) {
		Map<String, Object> result = new LinkedHashMap<>();
		Map<String, Object> partial = null;
		for (Tuple t: tuples) {
			partial = this.getInputParams(inputs, t);
			for (RESTAttribute a: inputs) {
				InputMethod im = a.getInputMethod();
				String pname = im.getParameterizedName(a.getInputParams());
				Object o = result.get(pname);
				if (o == null) {
					result.put(pname, partial.get(pname));
				} else if (a.allowsBatch()) {
					result.put(pname, String.valueOf(o) + im.getBatchDelimiter() + partial.get(pname));
				} else {
					throw new AccessException("Attempting to perform batch input, while access method does not allow it.");
				}
				
			}
		}
		if (partial != null) {
			for (RESTAttribute a: inputs) {
				InputMethod im = a.getInputMethod();
				String pname = im.getParameterizedName(a.getInputParams());
				partial.remove(pname);
			}
			result.putAll(partial);
		}
		return result;
	}

	/**
	 * @param inputs
	 * @param tuple
	 * @return a map containing input parameter to be use to build a service 
	 * request. The parameters include static parameters and access-specific
	 * parameters. The key of the map correspond to either input method names,
	 * template entries or the input attribute names themselves.
	 */
	private Map<String, Object> getInputParams(List<RESTAttribute> inputs, Tuple tuple) {
		Map<String, Object> result = new LinkedHashMap<>();
		for (RESTAttribute input: this.allAttributes) {
			InputMethod m = input.getInputMethod();
			Object value = null;
			int i = -1;
			if (input instanceof StaticInput) {
				value = ((StaticInput) input).getDefaultValue();
			} else {
				if ((i = inputs.indexOf(input)) >= 0) {
					value = tuple.getValue(i);
				} else {
					continue;
				}
			}

			if (m != null) {
				Collection<String> p = input.getInputParams();
				if (value == null) {
					value = m.getDefaultValue();
				}
				if (p != null && !p.isEmpty()) {
					for (String s: p) {
						result.put(m.getParameterizedName(p), value);
					}
				} else {
					result.put(m.getName(), value);
				}
			} else {
				result.put(input.getName(), value);
			}
		}
		return result;
	}


	/**
	 * Performs an access to the service for a batch of input tuples.
	 * @param inputAttributes
	 * @param inputTuples Table
	 * @return the dynamic table resulting from the access.
	 */
	public Table accessBatchInput(List<RESTAttribute> inputAttributes, Table inputTuples) {
//		Preconditions.checkArgument(inputAttributes.size() == 1);
//		Preconditions.checkArgument(inputTuples != null);
//		
//		DynamicTable cacheMisses = new DynamicTable(inputAttributes);
//		DynamicTable output = new DynamicTable(this.getAttributes());
//		for (Tuple t: inputTuples) {
//			DynamicTable cached = this.cache.get(t);
//			if (cached != null) {
//				output.appendRows(cached);
//			} else {
//				cacheMisses.appendRow(t);
//			}
//		}
//		
//		// Put all dynamic in a map
//		Set<InputMethod> inputMethods = this.getInputMethod(inputAttributes);
		
		Table result = new Table(this.getAttributes());
//		int batchSize = inputAttributes.get(0).getInputMethod().getBatchSize();
//
//		Iterator<Tuple> it = cacheMisses.iterator();
//		while (it.hasNext()) {
//			
//			// For each batch of batchSize
//			DynamicTable batchInput = new DynamicTable(inputAttributes);
//			for (int i = 0; i < batchSize && it.hasNext(); i++) {
//				batchInput.appendRow(it.next());
//			}
//
//			Map<String, Object> inputParams = this.getInputParams(inputAttributes, batchInput);
//			RESTAccess access = new RESTAccess(this.properties.getProperty(URL));
//			access.processParams(inputMethods, inputParams);
//			
//			AccessEvent event = null;
//			do {
//				// Keep requesting until the access is complete
//				event = new RESTRequestEvent(access, batchInput);
//				this.eventBus.post(event);
//				if (event.hasUsageViolationMessage()) {
//					throw new UsagePolicyViolationException(event.getUsageViolationMessage());
//				}
//
//				WebTarget target = access.build();
//				log.info(target.getUri());
//
//				// Connection to the remote server
//				Response response = target.request(MediaType.APPLICATION_JSON).get();
//				if (response.getStatus() == 200) {
//					output = this.parseResponse(response, batchInput);
//					event = new RESTResponseEvent(access, response, output);
//					this.eventBus.post(event);
//					if (event.hasUsageViolationMessage()) {
//						throw new UsagePolicyViolationException(event.getUsageViolationMessage());
//					}
//					result.appendRows(output);
//				} else if (response.getStatus() == 404) {
//					log.warn(response.getStatusInfo().getReasonPhrase());
//					break;
//				} else {
//					throw new AccessException(response.getStatus()
//							+ " - " + response.getStatusInfo().getReasonPhrase()
//							+ "\n" + response.readEntity(String.class));
//				}
//
//			} while(event.hasMoreElements());
//		}
//
		// TODO
//		this.cache.put(inputs, result);
		
		return result;
	}

	/**
	 * Performs an access to the service for a single input tuple.
	 * @param inputAttributes
	 * @param inputTuple
	 * @return the dynamic table resulting from the access.
	 */
	RESTResponseEvent accessSingleInput(List<RESTAttribute> inputAttributes, Tuple inputTuple) {
		Preconditions.checkArgument(inputTuple != null ?
					inputAttributes.size() == inputTuple.size() :
					inputAttributes.isEmpty());
		
		Table inputTable = new Table(inputAttributes);
		if (inputTuple != null) {
			inputTable.appendRow(inputTuple);
		}
		
		// Put all dynamic in a map
		Set<InputMethod> inputMethods = this.getInputMethod(inputAttributes);
		Map<String, Object> inputParams = this.getInputParams(inputAttributes, inputTuple);
		
		RESTAccess access = new RESTAccess(this.url);
		access.processParams(inputMethods, inputParams);
		return this.proceedAccess(new RESTRequestEvent(this, access, inputTable));
	}
	
	/**
	 * Performs an access to the service for a single input tuple.
	 * @return the dynamic table resulting from the access.
	 */
	RESTResponseEvent accessInputFree() {
		List<RESTAttribute> inputAttributes = new LinkedList<>();
		Table inputTable = new Table(inputAttributes);
		
		Set<InputMethod> inputMethods = this.getInputMethod(inputAttributes);
		Map<String, Object> inputParams = this.getInputParams(inputAttributes, Tuple.EmptyTuple);
		
		RESTAccess access = new RESTAccess(this.url);
		access.processParams(inputMethods, inputParams);
		return this.proceedAccess(new RESTRequestEvent(this, access, inputTable));
	}
	
	/**
	 * Processes an access request and response events in a row.
	 * @param requestEvent
	 * @return RESTResponseEvent
	 */
	RESTResponseEvent proceedAccess(RESTRequestEvent requestEvent) {
		this.eventBus.post(requestEvent);
		if (requestEvent.hasUsageViolationMessage()) {
			throw new UsagePolicyViolationException(requestEvent.getUsageViolationMessage());
		}
			
		RESTResponseEvent responseEvent = requestEvent.processRequest();
		this.eventBus.post(responseEvent);
		if (responseEvent.hasUsageViolationMessage()) {
			throw new UsagePolicyViolationException(responseEvent.getUsageViolationMessage());
		}
		return responseEvent;
	}
	
	/**
	 * Parse the response of a service call, so as to fit it is a dynamic table
	 * according to the output methods defined externally.
	 * @param response
	 * @param inputs Table
	 * @return a DynamicTable whose data has been extract from the given 
	 * response, using the output methods defined externally.
	 */
	Table parseResponse(Response response, Table inputs) {
		Table result = new Table(this.getAttributes());

		ObjectMapper mapper = new ObjectMapper();
		try {
			String s = response.readEntity(String.class);
			List<String> delim = this.getResultDelimiter();

			Object r = null;
			if (delim.isEmpty()) {
				try {
					r = mapper.readValue(s, List.class);
				} catch (JsonMappingException e) {
					log.debug(e);
					r = mapper.readValue(s, Map.class);
				}
			} else {
				r = mapper.readValue(s, Map.class);
			}
			
			for (Tuple t: this.processItems(
					delim, r, result.getType(), inputs)) {
				result.appendRow(t);
			}
			return result;
		} catch (IOException e) {
			throw new AccessException(e.getMessage(), e);
		}
	}

	/**
	 * @return a list of string representation path where the collection of 
	 * results can be found in a reponse.
	 */
	private List<String> getResultDelimiter() {
		String[] result = this.resultDelimiter.split("/");
		if (result.length == 1 && result[0].trim().isEmpty()) {
			result = new String[0];
		}
		return Lists.newArrayList(result);
	}
	
	/**
	 * Converts a collection of a loosely-typed maps to a collection of tuples.
	 * @param type
	 * @param delimiters List<String>
	 * @param response Object
	 * @param inputTable Table
	 * @return a collection of tuple representations of the given map,
	 * matching the given header and type.
	 */
	private Collection<Tuple> processItems(
			List<String> delimiters, Object response, TupleType type,
			Table inputTable) {
		Collection<Tuple> result = new LinkedList<>();
		if (!delimiters.isEmpty() && (response instanceof Map)) {
			int i = 0;
			Object items = null;
			do {
				items = ((Map) response).get(delimiters.get(i));
				if (items != null && items instanceof Map) {
					return this.processItems(
							delimiters.subList(i + 1, delimiters.size()),
							items, type, 
							inputTable);
				} else if (items != null && items instanceof Collection) {
					for (Map<String, Object> m: (Collection<Map<String, Object>>) items) {
						result.add(this.processItem(m, type, inputTable));
					}
					return result;
				}
				i++;
			} while (items == null && i < delimiters.size());
		} else if (response instanceof Collection) {
				for (Object o: ((Collection) response)) {
					result.addAll(this.processItems(delimiters, o, type, inputTable));
				}
		} else if (response instanceof Map) {
			Tuple t = this.processItem((Map) response, type, inputTable);
			if (t != null) {
				result.add(t);
			}
		} else {
			throw new AccessException("Could not deserialize response to Map/Collections.");
		}
		return result;
	}

	/**
	 * Converts the content of a loosely-typed map to a tuple.
	 * @param item
	 * @param type
	 * @param inputTable Table
	 * @return a tuple representation of the given map, matching the given header and type.
	 */
	private Tuple processItem(Map<String, Object> item, TupleType type, Table inputTable) {
		Object[] result = new Object[type.size()];
		int i = 0, j = 0;
		boolean hasValue = false;
		List<? extends Attribute> inputHeader = (List<Attribute>) inputTable.getHeader();
		Tuple first = inputTable.isEmpty() ? null: inputTable.iterator().next();
		for (Attribute column: this.attributes) {
			if (!inputHeader.contains(column)
					|| inputTable.size() > 1) {
				OutputMethod om = ((RESTAttribute) column).getOutputMethod();
				if (om != null) {
					result[i]= Types.cast(column.getType(), om.extract(item));
				}
				hasValue |= result[i] != null;
			} else if ((j = inputHeader.indexOf(column)) >=0 ) {
				result[i]= Types.cast(column.getType(), first.getValue(j));
			}
					
			i++;
		}
		return hasValue ? type.createTuple(result): null ;		
	}

	/**
	 * @param p UsagePolicy
	 * @see uk.ac.ox.cs.pdq.services.Service#register(UsagePolicy)
	 */
	@Override
	public void register(UsagePolicy p) {
		this.eventBus.register(p);
	}

	/**
	 * @param p UsagePolicy
	 * @see uk.ac.ox.cs.pdq.services.Service#unregister(UsagePolicy)
	 */
	@Override
	public void unregister(UsagePolicy p) {
		this.eventBus.unregister(p);
	}

	/**
	 * The class encapsulates the pipelined behaviour of the Wrapper.
	 * 
	 * @author Julien Leblay
	 */
	private class AccessIterator implements ResetableIterator<Tuple> {
		
		/** Iterator over the input tuples. */
		private final ResetableIterator<Tuple> inputs;

		/** The list of input attributes */
		private final List<RESTAttribute> inputAttributes;
		
		/** Iterator over a subset of the output tuples. */
		private List<Tuple> cached;

		/** Cursor of the current iterator over the current list of outputs. */
		private int cursor = 0;

		/**
		 * The next tuple to returns. This variable can only be null before the
		 * operator is instantiation or when there is not more tuple to output.
		 */
		private Tuple nextTuple;

		/** The access event that occurred */
		private RESTResponseEvent event = null;

		/** The last collection tuple considered as input */
		private Collection<Tuple> lastInput = null;
		
		/**
		 * Constructor without input tuples, i.e. free access
		 */
		public AccessIterator() {
			this(null, null);
		}
		
		/**
		 * Constructor with input tuple iterator
		 * @param inputAttributes List<RESTAttribute>
		 * @param inputTuples ResetableIterator<Tuple>
		 */
		public AccessIterator(List<RESTAttribute> inputAttributes, ResetableIterator<Tuple> inputTuples) {
			this.inputs = inputTuples;
			this.inputAttributes = inputAttributes;
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Iterator#open()
		 */
		@Override
		public void open() {
			synchronized (RESTRelation.this.cache) {
				this.lastInput = null;
				this.event = null;
				this.nextTuple = null;
				this.cached = null;
				this.cursor = 0;
				if (this.inputs != null) {
					this.inputs.open();
				}
				this.nextTuple();
			}
		}

		/*
		 * (non-Javadoc)
		 * @see java.util.Iterator#reset()
		 */
		@Override
		public void reset() {
			synchronized (RESTRelation.this.cache) {
				this.lastInput = null;
				this.event = null;
				this.nextTuple = null;
				this.cached = null;
				this.cursor = 0;
				if (this.inputs != null) {
					this.inputs.reset();
				}
				this.nextTuple();
			}
		}

		/**
		 * @return AccessIterator
		 * @see uk.ac.ox.cs.pdq.util.ResetableIterator#deepCopy()
		 */
		@Override
		public AccessIterator deepCopy() {
			return new AccessIterator(
					Lists.newArrayList(this.inputAttributes),
					this.inputs.deepCopy());
		}
		
		/**
		 * @return boolean
		 * @see java.util.Iterator#hasNext()
		 */
		@Override
		public boolean hasNext() {
			synchronized (RESTRelation.this.cache) {
				return this.nextTuple != null;
			}
		}

		/**
		 * @return Tuple
		 * @see java.util.Iterator#next()
		 */
		@Override
		public Tuple next() {
			synchronized (RESTRelation.this.cache) {
				if (this.nextTuple == null) {
					throw new NoSuchElementException();
				}
				Tuple result = this.nextTuple;

				if (this.cached == null) {
					this.nextTuple();
				} else if (this.cursor < this.cached.size()) {
					this.nextTuple = this.proceed();
				} else {
					// If this access is already started,
					// check if the last access input is complete
					if (this.event != null && this.event.hasMoreRequestEvents()) {
						RESTRequestEvent req = this.event.nextRequestEvent();
						this.event = RESTRelation.this.proceedAccess(req);
						if (!this.event.getOutput().isEmpty()) {
							this.cached.addAll(this.event.getOutput().getData());
							this.nextTuple = this.proceed();
							return result;
						}
					}
					this.cached = null;
					this.nextTuple();
				}
				return result;
			}
		}
		
		/**
		 * Set the next tuple to the following item on the output iterator, 
		 * using the next input tuple if necessary.
		 * The nextTuple is set to null, if the iterator has reached the end.
		 */
		public void nextTuple() {
			this.nextTuple = null;
			
			// No more intermediary result, and the access is not free
			if (this.inputs != null) {
				// Iterator over the input until you get a non-empty intermediary result
				while (this.inputs.hasNext() && this.cached == null) {
					Tuple input = this.inputs.next();
					this.lastInput = Lists.newArrayList(input);
					this.cached = RESTRelation.this.cache.get(this.lastInput);
					this.cursor = 0;

					// Cache miss: get new tuple from the service 
					if (this.cached == null) {
						this.event = RESTRelation.this
								.accessSingleInput(
										this.inputAttributes, input);
						if (!this.event.getOutput().isEmpty()) {
							this.cached = new ArrayList<>(this.event.getOutput().getData());
							RESTRelation.this.cache.put(this.lastInput, this.cached);
							break;
						}
					}
				}
			} else {
				this.lastInput = Lists.newArrayList(Tuple.EmptyTuple);
				this.cached = RESTRelation.this.cache.get(this.lastInput);
				if (this.cached == null) {
					this.event = RESTRelation.this.accessInputFree();
					if (!this.event.getOutput().isEmpty()) {
						this.cached = new ArrayList<>(this.event.getOutput().getData());
						this.cursor = 0;
						RESTRelation.this.cache.put(this.lastInput, this.cached);
					}
				}
			}
			this.nextTuple = this.proceed();
		}
		
		/**
		 * @return Tuple
		 */
		private Tuple proceed() {
			if (this.cached != null
					&& this.cursor < this.cached.size()
					) {
				return this.cached.get(this.cursor++);
			}
			return null;
		}

		/*
		 * (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			StringBuilder result = new StringBuilder();
			result.append(RESTRelation.class.getSimpleName()).append('{')
				.append(RESTRelation.this.getName()).append('}').append('.')
				.append(this.getClass().getSimpleName()).append('(')
				.append(this.inputs).append(')');
			
			return result.toString();
		}
		
		/*
		 * @see java.util.Iterator#remove()
		 */
		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}
}
