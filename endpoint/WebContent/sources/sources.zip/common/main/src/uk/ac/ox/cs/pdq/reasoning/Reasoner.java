package uk.ac.ox.cs.pdq.reasoning;

import java.util.Collection;

import uk.ac.ox.cs.pdq.db.Constraint;
import uk.ac.ox.cs.pdq.fol.PredicateFormula;


/**
 * Super interface encompassing all reasoners usable by the planner.
 *
 * @author Julien Leblay
 */
public interface Reasoner {

	/**
	 * Computes a fix point from a predefined state.
	 * @param s State
	 * @param dependencies Iterable<? extends IC>
	 */
	void fixpoint(State s, Iterable<? extends Constraint> dependencies);

	/**
	 * A reasoner's state.
	 *
	 * @author Julien Leblay
	 *
	 */
	public static interface State extends Cloneable {
		/**
		 * @return the facts of this.state
		 */
		Collection<PredicateFormula> getFacts();
	}
}
