package uk.ac.ox.cs.pdq.reasoning;

import uk.ac.ox.cs.pdq.plan.Plan;

/**
 * A configuration
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 */
public interface Configuration<P extends Plan> extends Cloneable, Comparable<Configuration<P>>{
	
	/**
	 * @return the plan of this configuration
	 */
	P getPlan();
	
	void setPlan(P plan);
	
	Configuration<P> clone();
	
	/**
	 * @return true if the configuration matches the target query 
	 */
	boolean isSuccessful();

	int compareTo(Configuration<P> o);
}
