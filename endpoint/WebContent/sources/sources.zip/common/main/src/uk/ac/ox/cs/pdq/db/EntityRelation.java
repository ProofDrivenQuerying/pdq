package uk.ac.ox.cs.pdq.db;

import java.util.List;

import uk.ac.ox.cs.pdq.db.AccessMethod.AccessMethodTypes;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;

/**
 * Entity relation are unary relation that also act as types.
 * @author Julien Leblay
 */
public class EntityRelation extends Relation implements DataType {

	private final Attribute attribute;
	private final List<Attribute> attributes;
	
	/**
	 * Construction for an inaccessible entity relation.
	 * @param name
	 * @param am
	 */
	public EntityRelation(String name) {
		super(name, Lists.<Attribute>newArrayList(new Attribute(EntityRelation.class, "_")),
				ImmutableList.<AccessMethod>of(),
				ImmutableList.<ForeignKey>of(), false);
		this.attribute = new Attribute(this, "_");
		this.attributes = ImmutableList.of(this.attribute);
	}

	/**
	 * Constructor for an accessible rentity relation.
	 * @param name
	 * @param am
	 */
	public EntityRelation(String name, AccessMethodTypes am) {
		super(name, Lists.<Attribute>newArrayList(new Attribute(EntityRelation.class, "_")),
				(am == AccessMethodTypes.FREE
				? ImmutableList.<AccessMethod>of(new AccessMethod("_", AccessMethodTypes.FREE, ImmutableList.<Integer>of())) :
				ImmutableList.<AccessMethod>of(new AccessMethod("_", am, ImmutableList.of(1)))),
				ImmutableList.<ForeignKey>of(), false);
		this.attribute = new Attribute(this, "_");
		this.attributes = ImmutableList.of(this.attribute);
	}
	
	@Override
	public List<Attribute> getAttributes() {
		return this.attributes;
	}
	
	@Override
	public Attribute getAttribute(int i) {
		return this.attributes.get(i);
	}
	
	/**
	 * Convenience method to get the unique attribute of an entity relation.
	 * @return the unique attribute of an entity relation.
	 */
	public Attribute getAttribute() {
		return this.attribute;
	}
	
	/**
	 * Convenience method to get the unique access method of an entity relation.
	 * @return the unique access method of the entity relation, or null if the
	 * relation is inaccessible.
	 */
	public AccessMethod getAccessMethod() {
		return super.getAccessMethod("_");
	}
}
