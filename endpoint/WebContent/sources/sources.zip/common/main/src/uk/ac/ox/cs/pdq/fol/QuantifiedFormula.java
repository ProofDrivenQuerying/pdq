package uk.ac.ox.cs.pdq.fol;

import static uk.ac.ox.cs.pdq.fol.LogicalSymbols.EXISTENTIAL;
import static uk.ac.ox.cs.pdq.fol.LogicalSymbols.UNIVERSAL;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

/**
 * A quantifier formula
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 *
 */
public abstract class QuantifiedFormula<T extends Formula> extends UnaryFormula<T> {

	/** The quantified variables*/
	protected final List<Variable> variables;

	/**
	 *
	 * @param operator
	 * 		Input quantifier operator
	 * @param variables
	 * 		Input quantified variables
	 * @param subFormula
	 * 		Input subformula
	 * 		Throws illegal argument exception when the input operator is not a quantifier one
	 */
	protected QuantifiedFormula(LogicalSymbols operator, List<Variable> variables, T subFormula) {
		super(operator, subFormula);
		assert(operator == UNIVERSAL || operator == EXISTENTIAL);
		assert(subFormula.getTerms().containsAll(variables));
		this.variables = variables;
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.operator.equals(((QuantifiedFormula<?>) o).operator)
				&& this.variables.equals(((QuantifiedFormula<?>) o).variables)
				&& this.subFormula.equals(((QuantifiedFormula<?>) o).subFormula);
	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.operator, this.variables, this.subFormula);
	}

	/**
	 * @return java.lang.String
	 */
	@Override
	public java.lang.String toString() {
		return this.operator.toString() + " " + Joiner.on(",").join(this.variables) + " "
				+ this.subFormula.toString();

	}

	/**
	 * @return List<Variable>
	 */
	public List<Variable> getVariables() {
		return this.variables;
	}

	/**
	 * @return boolean
	 */
	public boolean isUniversal() {
		return this.operator == LogicalSymbols.UNIVERSAL;
	}


	/**
	 * @return boolean
	 */
	public boolean isExistential() {
		return this.operator == LogicalSymbols.EXISTENTIAL;
	}

	/**
	 * Constructor for UniversallyQuantifiedFormula.
	 * @param variables List<Variable>
	 * @param subFormula T
	 */
	public static <T extends Formula> UniversallyQuantifiedFormula<T> forAll(List<Variable> variables, T subFormula) {
		return new UniversallyQuantifiedFormula<>(variables, subFormula);
	}

	/**
	 * Constructor for ExistentiallyQuantifiedFormula.
	 * @param variables List<Variable>
	 * @param subFormula T
	 */
	public static <T extends Formula> ExistentiallyQuantifiedFormula<T> thereExists(List<Variable> variables, T subFormula) {
		return new ExistentiallyQuantifiedFormula<>(variables, subFormula);
	}

	/**
	 */
	public static final class UniversallyQuantifiedFormula<T extends Formula> extends QuantifiedFormula<T>{

		/**
		 * Constructor for UniversallyQuantifiedFormula.
		 * @param variables List<Variable>
		 * @param subFormula T
		 */
		UniversallyQuantifiedFormula(List<Variable> variables, T subFormula) {
			super(UNIVERSAL, variables, subFormula);
		}

		/**
		 * @param mapping Map<Variable,Term>
		 * @return Formula
		 * @see uk.ac.ox.cs.pdq.formula.Formula#ground(Map<Variable,Term>)
		 */
		@Override
		public UniversallyQuantifiedFormula ground(Map<Variable, Constant> mapping) {
			Preconditions.checkArgument(Collections.disjoint(this.variables, mapping.keySet()), "Illegal grounding for quantifier formula " + this);
			return new UniversallyQuantifiedFormula<>(
					Lists.newArrayList(this.variables),
					this.subFormula.ground(mapping));
		}
	}

	/**
	 */
	public static final class ExistentiallyQuantifiedFormula<T extends Formula> extends QuantifiedFormula<T>{

		/**
		 * Constructor for ExistentiallyQuantifiedFormula.
		 * @param variables List<Variable>
		 * @param subFormula T
		 */
		ExistentiallyQuantifiedFormula(List<Variable> variables, T subFormula) {
			super(EXISTENTIAL, variables, subFormula);
		}

		/**
		 * @param mapping Map<Variable,Term>
		 * @return Formula
		 * @see uk.ac.ox.cs.pdq.formula.Formula#ground(Map<Variable,Term>)
		 */
		@Override
		public ExistentiallyQuantifiedFormula ground(Map<Variable, Constant> mapping) {
			Preconditions.checkArgument(Collections.disjoint(this.variables, mapping.keySet()), "Illegal grounding for quantifier formula " + this);
			return new ExistentiallyQuantifiedFormula<>(
					Lists.newArrayList(this.variables),
					this.subFormula.ground(mapping));
		}
	}
}
