package uk.ac.ox.cs.pdq.fol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableList;

/**
 * A n-ary formula
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 *
 * @param <T> Type of input formulas
 */
public abstract class NaryFormula<T extends Formula> extends AbstractFormula implements Iterable<T> {

	/** The formula's head operator*/
	protected final LogicalSymbols operator;

	/** The subformulae */
	protected final ImmutableList<T> subFormulas;

	/**
	 *
	 * @param operator
	 * 		Input head operator
	 * @param subFormulas
	 * 		Input subformulas
	 */
	public NaryFormula(LogicalSymbols operator, Collection<T> subFormulas) {
		super();
		this.operator = operator;
		this.subFormulas = ImmutableList.copyOf(subFormulas);
	}

	/**
	 * @return Collection<T>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getSubFormulas()
	 */
	@Override
	public Collection<T> getSubFormulas() {
		return this.subFormulas;
	}

	/**
	 * @return List<Term>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getTerms()
	 */
	@Override
	public List<Term> getTerms() {
		List<Term> terms = new ArrayList<>();
		for (Formula atomics:this.subFormulas) {
			terms.addAll(atomics.getTerms());
		}
		return terms;
	}

	/**
	 * @return List<PredicateFormula>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getPredicates()
	 */
	@Override
	public List<PredicateFormula> getPredicates() {
		List<PredicateFormula> result = new ArrayList<>();
		for (Formula item: this.subFormulas) {
			result.addAll(item.getPredicates());
		}
		return result;
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.operator.equals(((NaryFormula<T>) o).operator)
				&& this.subFormulas.equals(((NaryFormula<T>) o).subFormulas);
	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.operator, this.subFormulas);
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		return Joiner.on(this.operator.toString()).join(this.subFormulas);
	}

	/**
	 * @return int
	 */
	public int size() {
		return this.subFormulas.size();
	}

	/**
	 * @return boolean
	 */
	public boolean isEmpty() {
		return this.subFormulas.isEmpty();
	}

	/**
	 * @return LogicalSymbols
	 */
	public LogicalSymbols getSymbol() {
		return this.operator;
	}

	/**
	 * @return Iterator<T>
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<T> iterator() {
		return this.subFormulas.iterator();
	}
}