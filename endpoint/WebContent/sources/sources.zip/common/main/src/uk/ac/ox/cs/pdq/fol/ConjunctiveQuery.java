package uk.ac.ox.cs.pdq.fol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

/**
 * A conjunctive query
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 *
 */
public class ConjunctiveQuery extends AbstractFormula implements Query<Conjunction<PredicateFormula>> {

	/** The query's head part*/
	protected final PredicateFormula head;

	/** The query's body part*/
	protected final Conjunction<PredicateFormula> body;

	/** The terms in the head of the query*/
	protected final List<Term> freeTerms;

	/** The query's free variables i.e. head variables */
	protected final List<Variable> free;

	/** The query's bound variables*/
	protected final List<Variable> bound;

	/** Map of query's free variables to chase constants*/
	protected final Map<Variable, Constant> freeToCanonical;

	/** The constants that appear in the query's body*/
	protected final Collection<TypedConstant<?>> constants;

	/** The canonical query*/
	protected final Conjunction<PredicateFormula> canonicalQuery;

	protected final Map<Variable, Constant> canonicalMapping;

	/**
	 *
	 * @param name
	 * 		The query's name
	 * @param headTerms
	 * 		The query's head variables
	 * @param body
	 * 		The query's body
	 */
	public ConjunctiveQuery(String name, List<Term> headTerms, Conjunction<PredicateFormula> body) {
		this(new PredicateFormula(new Signature(name, headTerms.size()), headTerms), body);
	}


	/**
	 * @param head
	 * 		The query's head
	 * @param body
	 * 		The query's body
	 */
	public ConjunctiveQuery(PredicateFormula head, Conjunction<PredicateFormula> body) {
		this(head, body, getCanonicalMapping(body));
	}
	
	/**
	 * 
	 * @param head
	 * 		The query's head
	 * @param body
	 * 		The query's body
	 * @param canonicalMapping
	 * 		Mapping of query variables to constants  
	 */
	public ConjunctiveQuery(PredicateFormula head, Conjunction<PredicateFormula> body, Map<Variable, Constant> canonicalMapping) {
		super();
		List<Variable> free = head.getVariables();
		List<Variable> bound = Utility.getVariables(body.getPredicates());
		bound.removeAll(free);
		assert Collections.disjoint(free, bound): "Free and bound variables overlap.";
		assert Sets.difference(
				Sets.union(
						Sets.newLinkedHashSet(Utility.getVariables(body.getPredicates())),
						Sets.newLinkedHashSet(head.getVariables())),
						Sets.union(
								Sets.newLinkedHashSet(free),
								Sets.newLinkedHashSet(bound))).isEmpty():
									"Some variables are neither free nor bound.";
		this.free = free;
		this.head = head;
		this.bound = bound;
		this.body = body;
		this.freeTerms = head.getTerms();
		this.constants = extractSchemaConstants(body);
		this.canonicalMapping = canonicalMapping;
		this.freeToCanonical = getFreeToCanonical(head,canonicalMapping);
		this.canonicalQuery = this.ground(canonicalMapping);
	}

	/**
	 * @param right Conjunction<PredicateFormula>
	 * @return Collection<TypedConstant<?>>
	 */
	private static Collection<TypedConstant<?>> extractSchemaConstants(Conjunction<PredicateFormula> right) {
		Collection<TypedConstant<?>> constants = new LinkedHashSet<>();
		for(PredicateFormula predicate: right.getSubFormulas()) {
			for (Term term: predicate.getTerms()) {
				if (!term.isSkolem() && !term.isVariable()) {
					TypedConstant<?> schemaConstant = ((TypedConstant) term);
					Preconditions.checkState(schemaConstant != null);
					constants.add(schemaConstant);
				}
			}
		}
		return constants;
	}

	/**
	 * @return Map<Variable,Term>
	 */
	private static Map<Variable, Constant> getCanonicalMapping(Conjunction<PredicateFormula> body) {
		Map<Variable, Constant> canonicalMapping = new LinkedHashMap<>();
			for (PredicateFormula p: body) {
				for (Term t: p.getTerms()) {
					if (t.isVariable()) {
						Constant c = canonicalMapping.get(t);
						if (c == null) {
							c = new Skolem(CanonicalNamesGenerator.getName());
							canonicalMapping.put((Variable) t, c);
						}
					}
				}
			}
		return canonicalMapping;
	}
	
	private static Map<Variable, Constant> getFreeToCanonical(PredicateFormula head, Map<Variable, Constant> canonicalMapping) {
		Map<Variable, Constant> freeToCanonical = new LinkedHashMap<>();
		for(Term headTerm: head.getTerms()) {
			Constant chaseTerm  = canonicalMapping.get(headTerm);
			if (chaseTerm != null && !chaseTerm.isSkolem()) {
				throw new java.lang.IllegalStateException("Chase Term " + headTerm + ", " + head.getTerms());
			}
			if (headTerm.isVariable()) {
				freeToCanonical.put((Variable) headTerm, chaseTerm);
			}
		}
		return freeToCanonical;
	}
	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.formula.Query#ground(java.util.Map)
	 */
	@Override
	public Conjunction<PredicateFormula> ground(Map<Variable, Constant> mapping) {
		List<PredicateFormula> bodyAtoms = new ArrayList<>();
		for (PredicateFormula atom: this.body.getSubFormulas()) {
			bodyAtoms.add(atom.ground(mapping));
		}
		return Conjunction.of(bodyAtoms);
	}


	/**
	 * @return Conjunction<PredicateFormula>
	 * @see uk.ac.ox.cs.pdq.fol.Query#getCanonicalQuery()
	 */
	@Override
	public Conjunction<PredicateFormula> getCanonicalQuery() {
		return this.canonicalQuery;
	}

	/**
	 * @return List<Query<Conjunction<PredicateFormula>>>
	 * @see uk.ac.ox.cs.pdq.fol.Query#getImportantSubqueries()
	 */
	@Override
	public List<Query<Conjunction<PredicateFormula>>> getImportantSubqueries() {
		List<Query<Conjunction<PredicateFormula>>> queries = new ArrayList<>();
		Set<PredicateFormula> sets = new LinkedHashSet<>();
		sets.addAll(this.body.getSubFormulas());
		Set<Set<PredicateFormula>> subQueries = Sets.powerSet(sets);
		Iterator<Set<PredicateFormula>> subQueryIterator = subQueries.iterator();
		while (subQueryIterator.hasNext()) {
			Set<PredicateFormula> queryConjuncts = subQueryIterator.next();
			if(!queryConjuncts.isEmpty())
			{
				List<Variable> variables = Utility.getVariables(queryConjuncts);
				List<Variable> appearingBound = Lists.newArrayList(this.bound);
				appearingBound.retainAll(variables);

				Set<Set<Variable>> appearingBoundSets = Sets.powerSet(Sets.newLinkedHashSet(appearingBound));
				Iterator<Set<Variable>> appearingBoundIterator = appearingBoundSets.iterator();
				while (appearingBoundIterator.hasNext()) {
					Set<Variable> v = appearingBoundIterator.next();
					List<Variable> myfree = Lists.newArrayList(variables);
					myfree.removeAll(v);

					ConjunctiveQuery cq = new ConjunctiveQuery(
							new PredicateFormula(new Signature("Q", myfree.size()), new ArrayList<>(myfree)),
							Conjunction.of(queryConjuncts));
					queries.add(cq);
				}
			}
		}
		return queries;
	}

	/**
	 * @return List<PredicateFormula>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getPredicates()
	 */
	@Override
	public List<PredicateFormula> getPredicates() {
		List<PredicateFormula> result = new ArrayList<>();
		result.add(this.head);
		result.addAll(this.body.getPredicates());
		return result;
	}

	/**
	 * @return List<Term>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getTerms()
	 */
	@Override
	public List<Term> getTerms() {
		Set<Term> terms = new LinkedHashSet<>();
		terms.addAll(this.head.getTerms());
		terms.addAll(this.body.getTerms());
		return new ArrayList<>(terms);
	}

	/**
	 * @return boolean
	 * @see uk.ac.ox.cs.pdq.fol.Query#isBoolean()
	 */
	@Override
	public boolean isBoolean() {
		return this.free.isEmpty();
	}

	/**
	 * @return Conjunction<PredicateFormula>
	 * @see uk.ac.ox.cs.pdq.fol.Query#getBody()
	 */
	@Override
	public Conjunction<PredicateFormula> getBody() {
		return this.body;
	}

	/**
	 * @return PredicateFormula
	 * @see uk.ac.ox.cs.pdq.fol.Query#getHead()
	 */
	@Override
	public PredicateFormula getHead() {
		return this.head;
	}

	/**
	 * @return List<Variable>
	 */
	public List<Variable> getBound() {
		return this.bound;
	}

	/**
	 * @return List<Term>
	 * @see uk.ac.ox.cs.pdq.fol.Evaluatable#getFree()
	 */
	@Override
	public List<Term> getFree() {
		return this.freeTerms;
	}

	/**
	 * @return Collection<TypedConstant<?>>
	 * @see uk.ac.ox.cs.pdq.fol.Query#getSchemaConstants()
	 */
	@Override
	public Collection<TypedConstant<?>> getSchemaConstants() {
		return this.constants;
	}

	/**
	 * @return Map<Variable,Term>
	 * @see uk.ac.ox.cs.pdq.fol.Query#getFreeToCanonical()
	 */
	@Override
	public Map<Variable, Constant> getFreeToCanonical() {
		return this.freeToCanonical;
	}
	
	@Override
	public Map<Variable, Constant> canonicalMapping() {
		return this.canonicalMapping;
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.head.equals(((ConjunctiveQuery) o).head)
				&& this.body.equals(((ConjunctiveQuery) o).body)
				&& this.free.equals(((ConjunctiveQuery) o).free)
				&& this.bound.equals(((ConjunctiveQuery) o).bound);
	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.free, this.bound, this.head, this.body);
	}

	/**
	 * @return String
	 */
	@Override
	public String toString() {
		return this.getHead() + " <- " + this.bound + this.getBody();
	}

	/**
	 * @return Collection<PredicateFormula>
	 * @see uk.ac.ox.cs.pdq.fol.Formula#getSubFormulas()
	 */
	@Override
	public Collection<PredicateFormula> getSubFormulas() {
		return this.getBody().getSubFormulas();
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.fol.Rule#contains(uk.ac.ox.cs.pdq.fol.Signature)
	 */
	@Override
	public boolean contains(Signature s) {
		for (PredicateFormula atom: this.getPredicates()) {
			if (atom.getSignature().equals(s)) {
				return true;
			}
		}
		return false;
	}
}
