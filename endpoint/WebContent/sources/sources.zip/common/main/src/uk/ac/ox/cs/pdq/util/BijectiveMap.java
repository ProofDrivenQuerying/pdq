package uk.ac.ox.cs.pdq.util;

import java.util.HashMap;

/**
 *
 * A bijective mapping
 * @author Efthymia Tsamoura
 *
 * @param <K>
 * @param <V>
 */
public class BijectiveMap<K,V> extends HashMap<K,V>{

	public BijectiveMap() {
		super();
	}
}
