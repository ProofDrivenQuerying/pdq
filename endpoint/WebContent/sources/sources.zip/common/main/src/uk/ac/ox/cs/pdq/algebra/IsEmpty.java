package uk.ac.ox.cs.pdq.algebra;

import java.util.ArrayList;
import java.util.List;

import uk.ac.ox.cs.pdq.util.TupleType;

/**
 * IsEmpty of the boolean query operator. Return true if the database satisfies
 * the body of the query, false otherwise.
 *
 * @author Julien LEBLAY
 */
public class IsEmpty extends UnaryOperator {

	/**
	 * Instantiates a new operator.
	 *
	 * @param child LogicalOperator
	 */
	public IsEmpty(RelationalOperator child) {
		super(TupleType.DefaultFactory.create(Boolean.class), child);
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#deepCopy()
	 */
	@Override
	public IsEmpty deepCopy() throws RelationalOperatorException {
		return new IsEmpty(this.child.deepCopy());
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#getColumnsDisplay()
	 */
	@Override
	public List<String> getColumnsDisplay() {
		List<String> result = new ArrayList<>();
		result.add("IS_EMPTY");
		return result;
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isQuasiLeaf() {
		return false;
	}
}
