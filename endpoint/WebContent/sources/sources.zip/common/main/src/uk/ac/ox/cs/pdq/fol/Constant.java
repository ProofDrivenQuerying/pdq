package uk.ac.ox.cs.pdq.fol;

/**
 *
 * A constant term
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 *
 */
public interface Constant extends Term {
}
