package uk.ac.ox.cs.pdq.algebra;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;

import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.plan.EstimateProvider;
import uk.ac.ox.cs.pdq.rewrite.Rewritable;
import uk.ac.ox.cs.pdq.rewrite.Rewriter;
import uk.ac.ox.cs.pdq.rewrite.RewriterException;
import uk.ac.ox.cs.pdq.util.Operator;
import uk.ac.ox.cs.pdq.util.TupleType;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

/**
 * RelationalOperator defines a top-class for all logical relational operators.
 *
 * @author Julien Leblay
 */
public abstract class RelationalOperator implements Rewritable, Operator {

	/** */
	public static enum SharingType { NOTHING, CACHE, BLOCKING }

	/** The operator's type. */
	protected final TupleType outputType;

	/** The operator's input type. */
	protected final TupleType inputType;

	/** The operator's dataguide. */
	protected EstimateProvider<RelationalOperator> metadata;

	/**
	 * @return false if the operator has some unfulfilled inputs, true otherwise.
	 */
	public abstract boolean isClosed();

	/**
	 * Instantiates a new operator.
	 * @param input TupleType
	 * @param output TupleType
	 */
	protected RelationalOperator(TupleType input, TupleType output) {
		this.inputType = input;
		this.outputType = output;
	}

	/**
	 * Instantiates a new operator.
	 *
	 * @param output TupleType
	 */
	public RelationalOperator(TupleType output) {
		this(TupleType.EmptyTupleType, output);
	}

	/**
	 * Deep copy.
	 * @return a deep copy of the operator.
	 * @throws RelationalOperatorException
	 */
	public abstract RelationalOperator deepCopy() throws RelationalOperatorException;

	/**
	 * Gets the column at index i.
	 *
	 * @param i the index of the column to return.
	 * @return the column at index i.
	 */
	public abstract Term getColumn(int i);

	/**
	 * Gets the columns.
	 *
	 * @return the columns
	 */
	public abstract List<Term> getColumns();

	/**
	 * Gets the input term list.
	 *
	 * @return the list of input terms
	 */
	public abstract List<Term> getInputTerms();

	/**
	 * @return the tuple Type of this operator
	 */
	public TupleType getType() {
		return this.outputType;
	}

	/**
	 * @return the input tuple Type of this operator
	 */
	public TupleType getInputType() {
		return this.inputType;
	}

	/**
	 * @return a list of human readable column headers.
	 */
	public List<String> getColumnsDisplay() {
		List<String> result = new ArrayList<>();
		for (Term t: this.getColumns()) {
			result.add(t.toString());
		}
		return result;
	}

	/**
	 * @return true if is output of this operator is sorted.
	 */
	public EstimateProvider<RelationalOperator> getMetadata() {
		return this.metadata;
	}

	/**
	 * @param md
	 */
	public void setMetadata(EstimateProvider<RelationalOperator> md) {
		this.metadata = md;
	}

	/**
	 * @return the depth of the lowest descendant of this operator
	 */
	public abstract Integer getDepth();

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.outputType == ((RelationalOperator) o).outputType
				&& this.inputType == ((RelationalOperator) o).inputType
				&& this.metadata == ((RelationalOperator) o).metadata;

	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.outputType, this.inputType, this.metadata);
	}

	/**
	 * @return true if the operator is a leaf or the ancestor of a single leaf
	 */
	public abstract boolean isQuasiLeaf();

	/**
	 * @return true if the operator is left-deep
	 */
	public abstract boolean isLeftDeep();

	/**
	 * @return true if the operator is right-deep
	 */
	public abstract boolean isRightDeep();

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.rewrite.Rewritable#rewrite(uk.ac.ox.cs.pdq.rewrite.Rewriter)
	 */
	@Override
	public <I extends Rewritable, O> O rewrite(Rewriter<I, O> rewriter) throws RewriterException {
		return rewriter.rewrite((I) this);
	}

	/**
	 * @param operator
	 * @return the access operators that are children of the input operator
	 */
	public static Collection<AccessOperator> getAccesses(RelationalOperator operator) {
		Collection<AccessOperator> result = new LinkedHashSet<>();
		if (operator instanceof Scan) {
			result.add(((Scan) operator));
			return result;
		}
		if (operator instanceof Access) {
			result.add(((Access) operator));
			return result;
		}
		if (operator instanceof DependentAccess) {
			result.add(((DependentAccess) operator));
			return result;
		}
		if (operator instanceof NaryOperator) {
			for (RelationalOperator child: ((NaryOperator)operator).getChildren()) {
				result.addAll(getAccesses(child));
			}
			return result;
		}
		if (operator instanceof UnaryOperator) {
			result.addAll(getAccesses(((UnaryOperator)operator).getChild()));
		}
		return result;
	}

	/**
	 * @param operator
	 * @return the leave operators rooted below the input operator
	 */
	public static List<AccessOperator> getLeaves(RelationalOperator operator) {
		Preconditions.checkArgument(operator != null);
		if( operator instanceof NaryOperator) {
			List<AccessOperator> ops = new ArrayList<>();
			for (RelationalOperator child: ((NaryOperator)operator).getChildren()) {
				ops.addAll(getLeaves(child));
			}
			return ops;
		}
		if (operator instanceof AccessOperator) {
			return Lists.newArrayList((AccessOperator) operator);
		}
		if (operator instanceof UnaryOperator) {
			return getLeaves(((UnaryOperator) operator).getChild());
		}
		throw new IllegalStateException("Check " + operator);
	}
}
