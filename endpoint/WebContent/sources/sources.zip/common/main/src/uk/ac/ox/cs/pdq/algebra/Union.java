package uk.ac.ox.cs.pdq.algebra;

import java.util.ArrayList;
import java.util.List;

import uk.ac.ox.cs.pdq.fol.Term;

import com.google.common.collect.ImmutableList;

/**
 * Union the results of its children
 *
 * @author Julien Leblay
 */
public class Union extends NaryOperator {

	/**
	 * Instantiates a new operator.
	 *
	 * @param children the children
	 * @throws RelationalOperatorException
	 */
	public Union(List<RelationalOperator> children) throws RelationalOperatorException {
		super(ImmutableList.<Term>of(), inferType(children), children);
		if (this.children.isEmpty()) {
			throw new RelationalOperatorException("Attempting to instantiate union operator with an empty list of children.");
		}
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.NaryOperator#deepCopy()
	 */
	@Override
	public Union deepCopy() throws RelationalOperatorException {
		List<RelationalOperator> clones = new ArrayList<>();
		for (RelationalOperator child: this.children) {
			clones.add(child.deepCopy());
		}
		return new Union(clones);
	}
}
