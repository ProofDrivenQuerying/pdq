package uk.ac.ox.cs.pdq;

/**
 * Check the consistency of some parameters
 *
 * @author Julien Leblay
 */
public interface ConsistencyChecker<P extends Parameters> {
	/**
	 * @param p Parameters
	 * @throws InconsistentParametersException
	 */
	void check(P p) throws InconsistentParametersException;
}
