package uk.ac.ox.cs.pdq;

/**
 * Super-interface to all event planner handlers
 * @author Julien Leblay
 *
 */
public interface EventHandler {
}
