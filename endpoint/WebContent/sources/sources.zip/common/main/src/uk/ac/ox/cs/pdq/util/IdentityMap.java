package uk.ac.ox.cs.pdq.util;


/**
 * An identity mapping function
 * @author Efthymia Tsamoura
 *
 * @param <K>
 * @param <V>
 */
public class IdentityMap<K,V> extends BijectiveMap<K,V>{

	public IdentityMap() {
		super();
	}
}
