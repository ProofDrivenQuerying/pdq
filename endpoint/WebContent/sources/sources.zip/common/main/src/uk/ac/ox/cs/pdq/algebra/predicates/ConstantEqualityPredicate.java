package uk.ac.ox.cs.pdq.algebra.predicates;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.util.Tuple;

import com.google.common.base.Objects;

/**
 * Compares the value at a given position in a tuple with a value given by a
 * constant.
 *
 * @author Julien Leblay
 */
public class ConstantEqualityPredicate implements EqualityPredicate {

	private static Logger log = Logger.getLogger(ConstantEqualityPredicate.class);

	/** The position on which the predicate is evaluated */
	private final int position;

	/** The value to which the tuple must be equals at the given position */
	private final TypedConstant<?> value;

	/**
	 * Default construction
	 * @param position
	 * @param value
	 */
	public ConstantEqualityPredicate(int position, TypedConstant<?> value) {
		this.position = position;
		this.value = value;
	}

	/**
	 * @param t
	 * @return true if the tuple t satisfies the predicate
	 * @see uk.ac.ox.cs.pdq.algebra.predicates.Predicate#isSatisfied(Tuple)
	 */
	@Override
	public boolean isSatisfied(Tuple t) {
		Object sourceValue = t.getValue(this.position);
		Object targetValue = this.value.getValue();
		if (sourceValue == null) {
			return targetValue == null;
		}
		if (sourceValue instanceof Comparable<?> && targetValue instanceof Comparable<?>) {
			try {
				Method m = Comparable.class.getMethod("compareTo", Object.class);
				return ((int) m.invoke(sourceValue, targetValue)) == 0;
			} catch (NoSuchMethodException | SecurityException
					| IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				log.warn("Problem comparing " + sourceValue + " to " + targetValue + ": " + e);
			}
		}

		return sourceValue.equals(targetValue);
	}

	/**
	 * @return the position of the attribute to compare
	 * @see uk.ac.ox.cs.pdq.algebra.predicates.EqualityPredicate#getPosition()
	 */
	@Override
	public int getPosition() {
		return this.position;
	}

	/**
	 * @return the constant value to compare with
	 */
	public TypedConstant<?> getValue() {
		return this.value;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null) {
			return false;
		}
		return this.getClass().isInstance(o)
				&& this.position == ((ConstantEqualityPredicate) o).position
				&& this.value.equals(((ConstantEqualityPredicate) o).value);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hashCode(this.position, this.value);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append('#').append(this.position).append('=');
		result.append(this.value);
		return result.toString();
	}
}
