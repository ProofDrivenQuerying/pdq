package uk.ac.ox.cs.pdq.io.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import uk.ac.ox.cs.pdq.algebra.Access;
import uk.ac.ox.cs.pdq.algebra.CrossProduct;
import uk.ac.ox.cs.pdq.algebra.DependentAccess;
import uk.ac.ox.cs.pdq.algebra.DependentJoin;
import uk.ac.ox.cs.pdq.algebra.Join;
import uk.ac.ox.cs.pdq.algebra.Projection;
import uk.ac.ox.cs.pdq.algebra.RelationalOperator;
import uk.ac.ox.cs.pdq.algebra.Scan;
import uk.ac.ox.cs.pdq.algebra.Selection;
import uk.ac.ox.cs.pdq.algebra.StaticInput;
import uk.ac.ox.cs.pdq.algebra.predicates.AttributeEqualityPredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.ConjunctivePredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.ConstantEqualityPredicate;
import uk.ac.ox.cs.pdq.algebra.predicates.Predicate;
import uk.ac.ox.cs.pdq.db.AccessMethod;
import uk.ac.ox.cs.pdq.db.AccessMethod.AccessMethodTypes;
import uk.ac.ox.cs.pdq.db.Attribute;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.db.Schema;
import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.fol.Variable;
import uk.ac.ox.cs.pdq.plan.Plan.ControlFlows;
import uk.ac.ox.cs.pdq.util.Typed;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Reads physical operators from XML.
 * 
 * @author Julien Leblay
 */
public class OperatorReader extends AbstractXMLReader<RelationalOperator> {

	/** Logger. */
	private static Logger log = Logger.getLogger(OperatorReader.class);

	public static enum Types {
		SELECT, PROJECT, RENAME, STATIC_INPUT, CROSS_PRODUCT,
		DEPENDENT_ACCESS, ACCESS, DEPENDENT_JOIN, JOIN, ALIAS
	}
	
	/** The operator being built. */
	private RelationalOperator operator = null;

	/** The schema from which the relation come. */
	protected Schema schema = null;

	/** The plan operators control flow. */
	protected ControlFlows controlFlow;
	
	protected Types type;
	protected Join.Variants variant;
	
	protected Predicate predicate = null;

	protected List<Predicate> conjunction = Lists.newLinkedList();
	protected List<Integer> sideways = Lists.newLinkedList();
	protected List<Typed> outputs = Lists.newLinkedList();
	protected List<Term> projection = Lists.newLinkedList();
	protected Map<Integer, TypedConstant<?>> staticInputs = Maps.newLinkedHashMap();
	protected List<RelationalOperator> children = Lists.newLinkedList();
	
	protected String relationName;
	protected String accessMethodName;
	
	private boolean inConjunction = false;
	private boolean inOutputs = false;
	private boolean inOptions = false;
	private boolean inChildren = false;

	private final Map<String, RelationalOperator> aliases;
	private String alias;
	
	/**
	 * Default constructor
	 * 
	 * @param dependencies
	 */
	public OperatorReader(Schema schema, ControlFlows cf) {
		this(schema, cf, Maps.<String, RelationalOperator>newHashMap());
	}

	/**
	 * Default constructor
	 * 
	 * @param dependencies
	 */
	public OperatorReader(Schema schema, ControlFlows cf, Map<String, RelationalOperator> aliases) {
		this.schema = schema;
		this.controlFlow = cf;
		this.aliases = aliases;
	}
	
	public void addChild(RelationalOperator i) {
		this.children.add(i);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see uk.ac.ox.cs.pdq.provider.io.AbstractReader#load(java.io.InputStream)
	 */
	@Override
	public RelationalOperator read(InputStream in) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			parser.parse(in, this);
			return this.getOperator();
		} catch (ParserConfigurationException | SAXException | IOException e) {
			log.error(e);
		}
		return null;
	}

	/**
	 * @return the operator under construction
	 */
	public RelationalOperator getOperator() {
		return this.operator;
	}

	/*
	 * (non-Javadoc)
	 * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) {
		switch(QNames.parse(qName)) {
		case OPERATOR:
			this.type = Types.valueOf(this.getValue(atts, QNames.TYPE));
			this.alias = this.getValue(atts, QNames.NAME);
			Preconditions.checkState(this.type == Types.ALIAS ? this.alias != null : true);
			if (this.type == Types.JOIN) {
				this.variant = Join.Variants.valueOf(this.getValue(atts, QNames.VARIANT));
			}
			if (this.type == Types.DEPENDENT_JOIN) {
				String inputsString = this.getValue(atts, QNames.PARAM);
				if (!Strings.isNullOrEmpty(inputsString)) {
					this.sideways = new ArrayList<>();
					for (String position: inputsString.split(",")) {
						this.sideways.add(Integer.parseInt(position));
					}
				}
			}
			this.relationName = this.getValue(atts, QNames.RELATION);
			this.accessMethodName = this.getValue(atts, QNames.ACCESS_METHOD);
			break;

		case CONJUNCTION:
			this.inConjunction = true;
			this.conjunction = Lists.newArrayList();
			break;

		case PREDICATE:
			this.inConjunction = true;
			int left = Integer.valueOf(this.getValue(atts, QNames.LEFT));
			if (this.getValue(atts, QNames.RIGHT) == null) {
				this.predicate = new ConstantEqualityPredicate(
						left,
						new TypedConstant(
								uk.ac.ox.cs.pdq.util.Types.cast(
									this.outputs.get(left).getType(),
									this.getValue(atts, QNames.VALUE))));
			} else {
				this.predicate = new AttributeEqualityPredicate(
						left,
						Integer.valueOf(this.getValue(atts, QNames.RIGHT)));
			}
			break;

		case OUTPUTS:
			this.inOutputs = true;
			this.outputs = Lists.newLinkedList();
			break;

		case PROJECT:
			this.inOptions = true;
			this.projection = Lists.newLinkedList();
			break;

		case STATIC_INPUT:
			this.inOptions = true;
			this.staticInputs = Maps.newLinkedHashMap();
			break;
	
		case CHILDREN:
			this.inChildren = true;
			break;

		case ATTRIBUTE:
			if (this.inOutputs) {
				try {
					this.outputs.add(new Attribute(
							Class.forName(this.getValue(atts, QNames.TYPE)),
							this.getValue(atts, QNames.NAME)));
				} catch (ClassNotFoundException e) {
					throw new IllegalStateException();
				}
			} else if (this.inOptions) {
				this.projection.add(new Variable(this.getValue(atts, QNames.NAME)));
			} else {
				throw new IllegalStateException("Attempting to read term while not in output list.");
			}
			break;

		case CONSTANT:
			if (this.inOutputs) {
				try {
					this.outputs.add(
							new TypedConstant<>(uk.ac.ox.cs.pdq.util.Types.cast(
							Class.forName(this.getValue(atts, QNames.TYPE)),
							this.getValue(atts, QNames.VALUE))));
				} catch (ClassNotFoundException e) {
					throw new IllegalStateException();
				}
			} else if (this.inOptions) {
				try {
					this.projection.add(
							new TypedConstant<>(uk.ac.ox.cs.pdq.util.Types.cast(
									Class.forName(this.getValue(atts, QNames.TYPE)),
									this.getValue(atts, QNames.VALUE))));
				} catch (ClassNotFoundException e) {
					throw new IllegalStateException();
				}
			} else {
				throw new IllegalStateException("Attempting to read term while not in output list.");
			}
			break;

		case INPUT:
			if (this.inOptions) {
				try {
					this.staticInputs.put(
							Integer.valueOf(this.getValue(atts, QNames.ATTRIBUTE)),
							new TypedConstant<>(uk.ac.ox.cs.pdq.util.Types.cast(
							Class.forName(this.getValue(atts, QNames.TYPE)),
							this.getValue(atts, QNames.VALUE))));
				} catch (ClassNotFoundException e) {
					throw new IllegalStateException();
				}
			} else {
				throw new IllegalStateException("Attempting to read term while not in option list.");
			}
			break;

		default:
			if (this.inChildren) {
				log.warn("In children of " + this.getClass().getSimpleName());
			}
			break;
		}				
	}

	/*
	 * (non-Javadoc)
	 * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void endElement(String uri, String localName, String qName) {
		switch(QNames.parse(qName)) {
		case OPERATOR:
			
			switch (this.type) {
			case SELECT:
				this.operator = new Selection(this.predicate, this.children.get(0));
				break;
			case PROJECT:
				Map<Integer, Term> renaming = new LinkedHashMap<>();
				int i = 0;
				for (Term t: this.projection) {
					if (t.isVariable() || t.isSkolem()) {
						Term r = Utility.typedToTerm(this.outputs.get(i));
						if (!String.valueOf(r).equals(String.valueOf(t))) {
							renaming.put(this.children.get(0).getColumns().indexOf(t), r);
						}
					}
					i++;
				}
				this.operator = new Projection(this.children.get(0), renaming, this.projection);
				break;
			case STATIC_INPUT:
				this.operator = new StaticInput(Utility.toTypedConstants(this.outputs));
				break;
			case CROSS_PRODUCT:
				this.operator = new CrossProduct(this.children);
				break;
			case DEPENDENT_JOIN:
				if (this.sideways == null || this.sideways.isEmpty()) {
					log.warn("Sideways information missing. Inferring from LHS.");
					this.sideways = new ArrayList<>();
					for (Term t: this.children.get(1).getInputTerms()) {
						int index = this.children.get(0).getColumns().indexOf(t);
						if (index < 0) {
							throw new IllegalStateException("No sideways inputs provided");
						}
						this.sideways.add(index);
					}
				}
				this.operator = new DependentJoin(this.children, this.sideways);
				break;
			case JOIN:
				this.operator = new Join(this.predicate, this.children);
				((Join) this.operator).setVariant(this.variant);
				break;
			case ACCESS:
				Relation r = this.schema.getRelation(this.relationName);
				Preconditions.checkState(r != null, "Plan refers to unknow relation " + this.relationName);
				AccessMethod b = null;
				if (this.accessMethodName == null) {
					for (AccessMethod bm: r.getAccessMethods()) {
						if (bm.getType() == AccessMethodTypes.FREE) {
							b = bm;
							break;
						}
					}
				} else {
					b = r.getAccessMethod(this.accessMethodName);
				}
				if (b == null) {
					throw new IllegalStateException("No access method defined for relation " + this.accessMethodName);
				}
				if (this.children.isEmpty() && b.getType() == AccessMethodTypes.FREE) {
					this.operator = new Scan(r);
				} else if (this.controlFlow == ControlFlows.TOP_DOWN) {
					this.operator = new DependentAccess(r, b, this.staticInputs);
				} else if (this.controlFlow == ControlFlows.BOTTOM_UP) {
					this.operator = new Access(r, b, this.children.get(0));
				} else {
					throw new IllegalStateException("Limited access defined without proper inputs specification " + this.type);
				}
				break;
			case ALIAS:
				this.operator = this.aliases.get(this.alias);
				Preconditions.checkState(this.operator != null);
				break;
			default:
				throw new IllegalStateException("Unsupported operator type " + this.type);
			}
			if (this.type != Types.ALIAS && this.alias != null) {
				this.aliases.put(this.alias, this.operator);
			}
			this.alias = null;
			break;
		case CONJUNCTION:
			this.inConjunction = false;
			this.predicate = new ConjunctivePredicate<>(this.conjunction);
			this.conjunction = Lists.newArrayList();
			break;
		case PREDICATE:
			if (this.inConjunction) {
				this.conjunction.add(this.predicate);
			}
			break;
		case OUTPUTS:
			this.inOutputs = false;
			break;
		case PROJECT:
			this.inOptions = false;
			break;
		case STATIC_INPUT:
			this.inOptions = false;
			break;
		case CHILDREN:
			this.inChildren = false;
			break;
		}				
	}
}
