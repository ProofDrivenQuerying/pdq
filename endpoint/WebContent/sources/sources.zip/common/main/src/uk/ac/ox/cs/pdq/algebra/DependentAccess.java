package uk.ac.ox.cs.pdq.algebra;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import uk.ac.ox.cs.pdq.db.AccessMethod;
import uk.ac.ox.cs.pdq.db.Attribute;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.db.TypedConstant;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.util.TupleType;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.base.Joiner;


/**
 * Logical operator representation of a dependent access.
 *
 * @author Efthymia Tsamoura
 * @author Julien Leblay
 */
public class DependentAccess  extends RelationalOperator implements AccessOperator {

	/** The input table of the access. */
	private final Relation relation;

	/** The access method to use. */
	private final AccessMethod binding;

	/** The output columns */
	protected final List<Term> columns;

	/** The input terms*/
	protected final List<Term> inputTerms;

	protected final Map<Integer, TypedConstant<?>> staticInputs;

	/**
	 *
	 * @param relation
	 * @param binding
	 */
	public DependentAccess(Relation relation, AccessMethod binding) {
		this(relation, binding, Utility.typedToTerms(relation.getAttributes()));
	}

	/**
	 *
	 * @param relation
	 * @param binding
	 * @param terms
	 */
	public DependentAccess(Relation relation, AccessMethod binding, List<Term> terms) {
		this(relation, binding, inferStaticInput(terms, binding));
	}

	/**
	 * Instantiates a new projection.
	 *
	 * @param relation Relation
	 * @param binding AccessMethod
	 * @param staticInput Map<Integer,TypedConstant<?>>
	 */
	public DependentAccess(Relation relation, AccessMethod binding, Map<Integer, TypedConstant<?>> staticInput) {
		super(inferInputType(relation.getAttributes(), binding, staticInput.keySet()),
				TupleType.DefaultFactory.createFromTyped(relation.getAttributes()));
		this.relation = relation;
		this.binding = binding;
		this.columns = Utility.typedToTerms(relation.getAttributes());
		this.staticInputs = staticInput;
		this.inputTerms = Utility.typedToTerms(inferInputTerms(relation.getAttributes(), binding, staticInput.keySet()));
	}

	/**
	 * @param columns List<Term>
	 * @param binding AccessMethod
	 * @return Map<Integer,TypedConstant<?>>
	 */
	private static Map<Integer, TypedConstant<?>> inferStaticInput(List<Term> columns, AccessMethod binding) {
		Map<Integer, TypedConstant<?>> result = new LinkedHashMap<>();
		for(Integer i: binding.getInputs()) {
			Term t = columns.get(i - 1);
			if (!(t.isSkolem() || t.isVariable())) {
				result.put(i - 1, ((TypedConstant) t));
			}
		}
		return result;
	}

	/**
	 * @param columns List<Attribute>
	 * @param binding AccessMethod
	 * @param exclude Set<Integer>
	 * @return TupleType
	 */
	private static TupleType inferInputType(List<Attribute> columns, AccessMethod binding, Set<Integer> exclude) {
		return TupleType.DefaultFactory.createFromTyped(inferInputTerms(columns, binding, exclude));
	}

	/**
	 * @param columns List<Attribute>
	 * @param binding AccessMethod
	 * @param exclude Set<Integer>
	 * @return List<Attribute>
	 */
	private static List<Attribute> inferInputTerms(List<Attribute> columns, AccessMethod binding, Set<Integer> exclude) {
		List<Attribute> result = new ArrayList<>();
		for(Integer i: binding.getInputs()) {
			if (!exclude.contains(i - 1)) {
				result.add(columns.get(i - 1));
			}
		}
		return result;
	}

	/**
	 * @return Integer
	 */
	@Override
	public Integer getDepth() {
		return 1;
	}

	/**
	 * @return the static inputs of this access.
	 */
	public Map<Integer, TypedConstant<?>> getStaticInputs() {
		return this.staticInputs;
	}

	/**
	 * @return the accessed relation
	 * @see uk.ac.ox.cs.pdq.plan.AccessOperator#getRelation()
	 */
	@Override
	public Relation getRelation() {
		return this.relation;
	}

	/**
	 * @return the access method used
	 * @see uk.ac.ox.cs.pdq.plan.AccessOperator#getBinding()
	 */
	@Override
	public AccessMethod getBinding() {
		return this.binding;
	}


	/**
	 * @param i int
	 * @return Term
	 */
	@Override
	public Term getColumn(int i) {
		return this.columns.get(i);
	}

	/**
	 * @return List<Term>
	 */
	@Override
	public List<Term> getColumns() {
		return this.columns;
	}

	/**
	 * @return List<Term>
	 */
	@Override
	public List<Term> getInputTerms() {
		return this.inputTerms;
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#deepCopy()
	 */
	@Override
	public DependentAccess deepCopy() throws RelationalOperatorException {
		return new DependentAccess(this.relation, this.binding, this.staticInputs);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(this.getClass().getSimpleName()).append('{');
		result.append(this.relation.getName()).append('[');
		result.append(Joiner.on(",").join(this.binding.getInputs()));
		result.append(']').append('}');
		return result.toString();
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		return super.equals(o)
				&& this.getClass().isInstance(o)
				&& this.relation.equals(((DependentAccess) o).relation)
				&& this.binding.equals(((DependentAccess) o).binding)
				&& this.columns.equals(((DependentAccess) o).columns);

	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.outputType, this.inputType, this.columns,
				this.relation, this.binding, this.metadata);
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isClosed() {
		return this.inputTerms.isEmpty();
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isQuasiLeaf() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#isLeftDeep()
	 */
	@Override
	public boolean isLeftDeep() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#isRightDeep()
	 */
	@Override
	public boolean isRightDeep() {
		return true;
	}
}
