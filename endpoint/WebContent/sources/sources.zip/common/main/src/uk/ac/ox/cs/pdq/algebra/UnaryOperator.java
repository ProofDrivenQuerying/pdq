package uk.ac.ox.cs.pdq.algebra;

import java.util.List;
import java.util.Objects;

import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.util.TupleType;

import com.google.common.base.Preconditions;

/**
 * Superclass to all unary logical operator.
 *
 * @author Julien Leblay
 */
public abstract class UnaryOperator extends RelationalOperator {

	protected RelationalOperator child;

	/** The columns. */
	protected final List<Term> columns;

	/** The input terms . */
	protected final List<Term> inputTerms;

	/** The position of the input term among the outputs. */
	protected List<Integer> inputMapping;

	/**
	 * Instantiates a new operator.
	 *
	 * @param inputType TupleType
	 * @param inputTerms List<Term>
	 * @param outputOverride TupleType
	 * @param columns List<Term>
	 * @param child LogicalOperator
	 */
	protected UnaryOperator(
			TupleType inputType, List<Term> inputTerms,
			TupleType outputOverride, List<Term> columns, RelationalOperator child) {
		super(inputType, outputOverride);
		Preconditions.checkArgument(inputType.size() == inputTerms.size());
		this.child = child;
		this.columns = columns;
		this.inputTerms = inputTerms;
	}

	/**
	 * Instantiates a new operator.
	 *
	 * @param typeOverride TupleType
	 * @param columns List<Term>
	 * @param child LogicalOperator
	 */
	public UnaryOperator(TupleType typeOverride, List<Term> columns, RelationalOperator child) {
		this(child.getInputType(), child.getInputTerms(), typeOverride, columns, child);
	}

	/**
	 * Instantiates a new operator.
	 *
	 * @param typeOverride TupleType
	 * @param child LogicalOperator
	 */
	public UnaryOperator(TupleType typeOverride, RelationalOperator child) {
		this(typeOverride, child.getColumns(), child);
	}

	/**
	 * Instantiates a new operator.
	 *
	 * @param child LogicalOperator
	 */
	public UnaryOperator(RelationalOperator child) {
		this(child.getType(), child);
	}

	/**
	 * @return the unique child of this operator
	 */
	public RelationalOperator getChild() {
		return this.child;
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#getColumn(int)
	 */
	@Override
	public Term getColumn(int i) {
		return this.columns.get(i);
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#getColumns()
	 */
	@Override
	public List<Term> getColumns() {
		return this.columns;
	}

	/**
	 * @return List<Term>
	 */
	@Override
	public List<Term> getInputTerms() {
		return this.inputTerms;
	}

	/**
	 * @return Integer
	 */
	@Override
	public Integer getDepth() {
		return this.child.getDepth() + 1;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(this.getClass().getSimpleName()).append('(');
		result.append(this.child.toString());
		result.append(')');
		return result.toString();
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		return super.equals(o)
				&& this.getClass().isInstance(o)
				&& (this.child == null ? ((UnaryOperator) o).child == null : this.child.equals(((UnaryOperator) o).child))
				&& this.columns.equals(((UnaryOperator) o).columns)
				&& this.inputTerms.equals(((UnaryOperator) o).inputTerms)
				;

	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.outputType, this.metadata, this.inputType,
				this.child, this.columns, this.inputTerms);
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isClosed() {
		return this.child.isClosed();
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isQuasiLeaf() {
		return this.child.isQuasiLeaf();
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#isLeftDeep()
	 */
	@Override
	public boolean isLeftDeep() {
		return this.child.isLeftDeep();
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#isRightDeep()
	 */
	@Override
	public boolean isRightDeep() {
		return this.child.isRightDeep();
	}
}