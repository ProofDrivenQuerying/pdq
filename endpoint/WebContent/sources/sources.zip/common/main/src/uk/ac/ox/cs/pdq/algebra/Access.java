package uk.ac.ox.cs.pdq.algebra;

import java.util.Objects;

import uk.ac.ox.cs.pdq.db.AccessMethod;
import uk.ac.ox.cs.pdq.db.Relation;
import uk.ac.ox.cs.pdq.fol.Term;
import uk.ac.ox.cs.pdq.plan.AccessOperator;
import uk.ac.ox.cs.pdq.util.TupleType;
import uk.ac.ox.cs.pdq.util.Utility;

import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

/**
 * Logical operator representation of an access.
 *
 * @author Julien Leblay
 */
public class Access extends UnaryOperator implements AccessOperator {

	/** The input table of the access. */
	private final Relation relation;

	/** The access method to use. */
	private final AccessMethod binding;

	/**
	 * Instantiates a new projection.
	 *
	 * @param relation Relation
	 * @param binding AccessMethod
	 */
	public Access(Relation relation, AccessMethod binding) {
		this(relation, binding, null);
	}

	/**
	 * Instantiates a new projection.
	 *
	 * @param relation Relation
	 * @param binding AccessMethod
	 * @param child LogicalOperator
	 */
	public Access(Relation relation, AccessMethod binding, RelationalOperator child) {
		super(	(child == null || child instanceof SubPlanAlias) ? TupleType.EmptyTupleType : child.getInputType(),
				(child == null || child instanceof SubPlanAlias) ? Lists.<Term>newArrayList() : child.getInputTerms(),
						TupleType.DefaultFactory.createFromTyped(relation.getAttributes()),
						Utility.typedToTerms(relation.getAttributes()),
						child);
		Preconditions.checkArgument(relation != null);
		Preconditions.checkArgument(binding != null);
		this.relation = relation;
		this.binding = binding;
	}

	/**
	 * @return the relation accessed by this operator.
	 * @see uk.ac.ox.cs.pdq.plan.AccessOperator#getRelation()
	 */
	@Override
	public Relation getRelation() {
		return this.relation;
	}

	/**
	 * @return the access method used by this operator.
	 * @see uk.ac.ox.cs.pdq.plan.AccessOperator#getBinding()
	 */
	@Override
	public AccessMethod getBinding() {
		return this.binding;
	}

	/*
	 * (non-Javadoc)
	 * @see uk.ac.ox.cs.pdq.plan.relational.logical.LogicalOperator#deepCopy()
	 */
	@Override
	public Access deepCopy() throws RelationalOperatorException {
		return new Access(this.relation, this.binding, this.child);
	}

	/**
	 * @param c LogicalOperator
	 */
	public void setChild(RelationalOperator c) {
		Preconditions.checkArgument(c != null);
		Preconditions.checkArgument(c.getType().size() == this.binding.getInputs().size(), "Inputs: " + this.binding + ", Child operator: " + c.getColumns());
		this.child = c;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(this.getClass().getSimpleName()).append('{');
		result.append(this.relation.getName()).append('[');
		result.append(Joiner.on(",").join(this.binding.getInputs()));
		result.append(']').append('}').append('(');
		result.append(this.child).append(')');
		return result.toString();
	}

	/**
	 * @return boolean
	 */
	@Override
	public boolean isClosed() {
		return this.child != null && this.child.isClosed();
	}

	/**
	 * @param o Object
	 * @return boolean
	 */
	@Override
	public boolean equals(Object o) {
		return super.equals(o)
				&& this.getClass().isInstance(o)
				&& this.relation.equals(((Access) o).relation)
				&& this.binding.equals(((Access) o).binding)
				;

	}

	/**
	 * @return int
	 */
	@Override
	public int hashCode() {
		return Objects.hash(this.outputType, this.inputType, this.child,
				this.columns, this.inputTerms, this.relation, this.binding,
				this.metadata);
	}
}
