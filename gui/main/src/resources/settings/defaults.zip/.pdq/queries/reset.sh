cp -f 0_0.q2 0_0.q
